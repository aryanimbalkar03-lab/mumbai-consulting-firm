import { CheckCircle, Sparkles, DollarSign, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const expertiseAreas = [
  'AI-Powered Business Analysis',
  'Strategic Planning & Execution',
  'Digital Innovation & Technology',
  'Operational Excellence',
  'Financial Optimization',
  'Market Entry & Growth Strategy'
];

const benefits = [
  { 
    icon: Sparkles, 
    title: 'AI-Powered Insights', 
    description: 'We use cutting-edge AI to analyze your business and uncover hidden opportunities'
  },
  { 
    icon: DollarSign, 
    title: 'Affordable Pricing', 
    description: 'Our rates are designed to be accessible because we believe in your growth'
  },
  { 
    icon: Clock, 
    title: 'Free Detailed Audit', 
    description: 'Get a comprehensive audit at no cost. Only pay if you choose to work with us'
  }
];

export function Expertise() {
  return (
    <section id="expertise" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="mb-6">Why Choose Mumbai Consulting Firm</h2>
            <p className="text-text-light mb-8">
              We{"'"}re a new-age consulting firm that combines human expertise with artificial intelligence. 
              Unlike traditional firms, we offer a <span className="text-primary">FREE detailed audit first</span>. 
              If consulting is needed, we{"'"}ll work together at affordable rates because your growth is our mission.
            </p>
            
            <div className="space-y-4 mb-8">
              {expertiseAreas.map((area, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle className="text-primary flex-shrink-0" size={24} />
                  <span className="text-text">{area}</span>
                </div>
              ))}
            </div>

            <div className="space-y-6">
              {benefits.map((benefit, index) => {
                const Icon = benefit.icon;
                return (
                  <div key={index} className="bg-white p-6 rounded-lg border-l-4 border-primary shadow-sm">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="text-secondary" size={24} />
                      </div>
                      <div>
                        <h3 className="mb-2">{benefit.title}</h3>
                        <p className="text-text-light text-base">{benefit.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-lg overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1568992687947-868a62a9f521?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjB0ZWFtd29ya3xlbnwxfHx8fDE3NjU0MDkzNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Team collaboration"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -top-6 -left-6 w-48 h-48 bg-primary rounded-lg -z-10 hidden md:block"></div>
          </div>
        </div>
      </div>
    </section>
  );
}