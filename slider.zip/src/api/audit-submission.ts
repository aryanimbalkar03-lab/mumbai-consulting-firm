/**
 * API Route: /api/audit-submission
 * Handles complete audit form submissions
 * - Sends detailed email with all audit data
 * - Saves comprehensive data to Google Sheets
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import nodemailer from 'nodemailer';
import { google } from 'googleapis';

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD,
  },
});

// Google Sheets configuration
const auth = new google.auth.GoogleAuth({
  credentials: JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY || '{}'),
  scopes: ['https://www.googleapis.com/auth/spreadsheets'],
});

const SPREADSHEET_ID = process.env.GOOGLE_SPREADSHEET_ID;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const data = req.body;
    const { name, email, phone, countryCode, businessName, auditData, results, timestamp } = data;

    // Generate HTML table for audit results
    const resultsHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FF1493, #C71585); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #fff; padding: 30px; border: 2px solid #FF1493; border-top: none; border-radius: 0 0 10px 10px; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th { background: #FF1493; color: white; padding: 12px; text-align: left; }
            td { padding: 12px; border-bottom: 1px solid #ddd; }
            .highlight { background: #fff0f8; }
            .critical { background: #fee; color: #c00; font-weight: bold; }
            .warning { background: #fff3cd; color: #856404; }
            .success { background: #d4edda; color: #155724; }
            .score-box { background: linear-gradient(135deg, #FF1493, #C71585); color: white; padding: 20px; border-radius: 10px; text-align: center; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">📊 AUDIT SUBMISSION COMPLETED!</h1>
              <p style="margin: 10px 0 0 0;">Mumbai Consulting Firm</p>
            </div>
            <div class="content">
              
              <h2 style="color: #FF1493;">Customer Information</h2>
              <table>
                <tr><th>Field</th><th>Value</th></tr>
                <tr class="highlight"><td><strong>Name</strong></td><td>${name}</td></tr>
                <tr><td><strong>Email</strong></td><td><a href="mailto:${email}">${email}</a></td></tr>
                <tr class="highlight"><td><strong>Phone</strong></td><td><a href="tel:${countryCode}${phone}">${countryCode} ${phone}</a></td></tr>
                <tr><td><strong>Business</strong></td><td>${businessName}</td></tr>
                <tr class="highlight"><td><strong>Industry</strong></td><td>${auditData.industry}</td></tr>
              </table>

              <div class="score-box">
                <h2 style="margin: 0 0 10px 0;">Health Score</h2>
                <div style="font-size: 48px; font-weight: bold;">${results.healthScore}/100</div>
                <p style="margin: 10px 0 0 0;">${results.consultingNeeded ? '🚨 CONSULTING NEEDED' : '✅ HEALTHY BUSINESS'}</p>
              </div>

              <h2 style="color: #FF1493;">Business Metrics</h2>
              <table>
                <tr><th>Metric</th><th>Value</th></tr>
                <tr class="highlight"><td>Current Year Revenue</td><td>₹${auditData.year1Revenue}</td></tr>
                <tr><td>Last Year Revenue</td><td>₹${auditData.year2Revenue || 'NA'}</td></tr>
                <tr class="highlight"><td>Gross Margin</td><td>${auditData.grossMargin ? auditData.grossMargin.toFixed(1) + '%' : 'NA'}</td></tr>
                <tr><td>Monthly Churn</td><td>${auditData.monthlyChurn || 'NA'}%</td></tr>
                <tr class="highlight"><td>CAC</td><td>₹${auditData.cac ? auditData.cac.toFixed(0) : 'NA'}</td></tr>
                <tr><td>LTV</td><td>₹${auditData.ltv ? auditData.ltv.toFixed(0) : 'NA'}</td></tr>
                <tr class="highlight"><td>Current Ratio</td><td>${auditData.currentRatio ? auditData.currentRatio.toFixed(2) : 'NA'}</td></tr>
                <tr><td>Revenue Growth (YoY)</td><td>${auditData.revenueGrowth ? auditData.revenueGrowth.toFixed(1) + '%' : 'NA'}</td></tr>
                <tr class="highlight"><td>Revenue Sources</td><td>${auditData.revenueSources || 'NA'}</td></tr>
              </table>

              ${results.redFlagsCount > 0 ? `
              <h2 style="color: #c00;">⚠️ Red Flags Detected (${results.redFlagsCount})</h2>
              <table>
                <tr><th>Component</th><th>Severity</th><th>Issue</th></tr>
                ${results.redFlags.map((flag: any, idx: number) => `
                  <tr class="${flag.severity === 'critical' ? 'critical' : flag.severity === 'high' ? 'warning' : 'highlight'}">
                    <td>${flag.component}</td>
                    <td>${flag.severity.toUpperCase()}</td>
                    <td>${flag.message}</td>
                  </tr>
                `).join('')}
              </table>
              ` : '<div class="success" style="padding: 20px; border-radius: 10px;"><h3>✅ No Critical Issues Detected</h3><p>This business is operating within healthy parameters.</p></div>'}

              <div style="background: #fff0f8; border-left: 4px solid #FF1493; padding: 15px; margin: 20px 0;">
                <p style="margin: 0;"><strong>⚡ Next Steps:</strong></p>
                <ul style="margin: 10px 0;">
                  <li>Contact ${name} at <a href="mailto:${email}">${email}</a></li>
                  <li>Call: <a href="tel:${countryCode}${phone}">${countryCode} ${phone}</a></li>
                  <li>Schedule consultation if consulting is needed</li>
                  <li>Review full data in Google Sheets</li>
                </ul>
              </div>

            </div>
          </div>
        </body>
      </html>
    `;

    // Send email
    await transporter.sendMail({
      from: `"MCF Audit System" <${process.env.GMAIL_USER}>`,
      to: 'aryanimbalkar03@gmail.com',
      subject: `📊 AUDIT COMPLETED: ${name} - ${businessName} (Score: ${results.healthScore}/100)`,
      html: resultsHtml,
    });

    // Save to Google Sheets
    const sheets = google.sheets({ version: 'v4', auth });
    
    const auditValues = [
      [
        new Date(timestamp).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
        name,
        email,
        `${countryCode} ${phone}`,
        businessName,
        auditData.industry,
        auditData.year1Revenue,
        auditData.year2Revenue || '',
        auditData.year3Revenue || '',
        auditData.grossMargin || '',
        auditData.monthlyChurn || '',
        auditData.repeatPurchase || '',
        auditData.cac || '',
        auditData.ltv || '',
        auditData.currentRatio || '',
        auditData.revenueGrowth || '',
        auditData.revenueSources || '',
        results.healthScore,
        results.consultingNeeded ? 'YES' : 'NO',
        results.redFlagsCount,
        results.redFlags.map((f: any) => `${f.severity.toUpperCase()}: ${f.component}`).join(' | '),
      ],
    ];

    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Audits!A:U', // Sheet name: "Audits"
      valueInputOption: 'RAW',
      requestBody: { values: auditValues },
    });

    return res.status(200).json({ 
      success: true,
      message: 'Audit data saved successfully',
    });

  } catch (error) {
    console.error('Error processing audit:', error);
    return res.status(500).json({ 
      error: 'Failed to process audit',
      details: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}
