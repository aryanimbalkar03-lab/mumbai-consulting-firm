/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  reactStrictMode: true,
  
  // GitHub Pages configuration
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || '',
  assetPrefix: process.env.NEXT_PUBLIC_BASE_PATH || '',
  
  // Disable image optimization for static export
  images: {
    unoptimized: true,
  },
  
  // Performance optimizations
  poweredByHeader: false,
  compress: true,
  
  // Production optimizations
  swcMinify: true,
  
  // Trailing slash for GitHub Pages
  trailingSlash: true,
}

module.exports = nextConfig