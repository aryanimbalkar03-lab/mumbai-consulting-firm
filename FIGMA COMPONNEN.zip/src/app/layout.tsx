import type { Metadata } from 'next'
import '../styles/globals.css'

export const metadata: Metadata = {
  title: 'Mumbai Consulting Firm | Transform Your Business Growth',
  description: 'Strategic consulting that maximizes profitability through data-driven insights. Free business assessment. Transparent, honest, results-driven consulting services for young businesses.',
  keywords: 'business consulting, Mumbai consulting, strategic consulting, business growth, free audit, business assessment, profitability consulting',
  authors: [{ name: 'Mumbai Consulting Firm' }],
  creator: 'Mumbai Consulting Firm',
  publisher: 'Mumbai Consulting Firm',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://mumbai-consulting.vercel.app'),
  openGraph: {
    title: 'Mumbai Consulting Firm | Transform Your Business Growth',
    description: 'Strategic consulting that maximizes profitability through data-driven insights. Free business assessment.',
    url: 'https://mumbai-consulting.vercel.app',
    siteName: 'Mumbai Consulting Firm',
    locale: 'en_IN',
    type: 'website',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Mumbai Consulting Firm - Strategic Business Consulting',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Mumbai Consulting Firm | Transform Your Business Growth',
    description: 'Strategic consulting that maximizes profitability through data-driven insights.',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'verification_token', // Add your Google Search Console verification token
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        {/* Favicons */}
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        
        {/* Theme and Mobile Optimization */}
        <meta name="theme-color" content="#FF1493" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        
        {/* Preconnect for Performance */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="dns-prefetch" href="https://fonts.googleapis.com" />
      </head>
      <body>{children}</body>
    </html>
  )
}