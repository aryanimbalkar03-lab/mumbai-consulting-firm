import { TrendingUp, Zap, Settings, DollarSign, Users, BarChart } from 'lucide-react';

const services = [
  {
    id: 1,
    icon: TrendingUp,
    title: 'Strategy Consulting',
    description: 'Develop comprehensive business strategies that align with your vision and market opportunities.'
  },
  {
    id: 2,
    icon: Zap,
    title: 'Digital Transformation',
    description: 'Modernize your operations with cutting-edge technology and digital solutions.'
  },
  {
    id: 3,
    icon: Settings,
    title: 'Operations Optimization',
    description: 'Streamline processes and enhance efficiency to maximize productivity and reduce costs.'
  },
  {
    id: 4,
    icon: DollarSign,
    title: 'Financial Advisory',
    description: 'Navigate complex financial decisions with expert guidance and data-driven insights.'
  },
  {
    id: 5,
    icon: Users,
    title: 'Change Management',
    description: 'Guide your organization through transformation with proven change management methodologies.'
  },
  {
    id: 6,
    icon: BarChart,
    title: 'Performance Analytics',
    description: 'Leverage data analytics to measure, track, and improve business performance metrics.'
  }
];

export function Services() {
  return (
    <section id="services" className="py-20 bg-gradient-to-br from-white via-gray-50 to-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16 animate-fadeInUp">
          <div className="inline-block px-6 py-2 bg-primary/10 border-2 border-primary rounded-full mb-4">
            <span className="text-primary tracking-wide font-bold" style={{ fontFamily: 'var(--font-heading)' }}>WHAT WE DO</span>
          </div>
          <h2 className="mb-4 text-5xl md:text-6xl font-black" style={{ fontFamily: 'var(--font-heading)' }}>
            SERVICES
          </h2>
          <p className="text-text-light max-w-2xl mx-auto text-lg" style={{ fontFamily: 'var(--font-heading)' }}>
            Comprehensive consulting solutions tailored to your unique business challenges and goals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div 
                key={service.id}
                className="p-8 bg-white border-2 border-gray-200 rounded-2xl hover:border-primary transition-all duration-300 hover:shadow-2xl hover:shadow-primary/10 group transform hover:-translate-y-2 animate-fadeInUp"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-pink-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg">
                  <Icon size={32} className="text-white" />
                </div>
                <h3 className="mb-3 text-2xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>{service.title}</h3>
                <p className="text-text-light leading-relaxed" style={{ fontFamily: 'var(--font-heading)' }}>{service.description}</p>
                <div className="mt-6 flex items-center text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="text-sm font-semibold" style={{ fontFamily: 'var(--font-heading)' }}>Learn more</span>
                  <svg className="w-4 h-4 ml-2 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}