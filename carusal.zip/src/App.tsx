import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Assessment } from './components/Assessment';
import { Expertise } from './components/Expertise';
import { Footer } from './components/Footer';
import { LeadCaptureModal, LeadData } from './components/LeadCaptureModal';
import { BookingModal } from './components/BookingModal';

export default function App() {
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showAssessment, setShowAssessment] = useState(false);
  const [leadData, setLeadData] = useState<LeadData | null>(null);

  const handleGetAudit = () => {
    setShowLeadModal(true);
  };

  const handleBookNow = () => {
    setShowBookingModal(true);
  };

  const handleLeadSubmit = async (data: LeadData) => {
    setLeadData(data);
    
    // Send data to backend
    try {
      const response = await fetch('/api/lead-capture', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          timestamp: new Date().toISOString(),
          source: 'Free Audit Request',
        }),
      });

      if (!response.ok) {
        console.error('Failed to submit lead data');
      }
    } catch (error) {
      console.error('Error submitting lead:', error);
      // Continue anyway to show assessment - we don't want to block the user
    }

    // Close modal and show assessment
    setShowLeadModal(false);
    setShowAssessment(true);
    
    // Scroll to assessment
    setTimeout(() => {
      const assessmentEl = document.getElementById('assessment');
      if (assessmentEl) {
        assessmentEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen">
      <Header onGetAudit={handleGetAudit} onBookNow={handleBookNow} />
      
      <main>
        <Hero onGetAudit={handleGetAudit} onBookNow={handleBookNow} />
        
        <Services />
        
        {/* Only show assessment after lead capture */}
        {showAssessment && leadData && (
          <div className="animate-fadeInUp">
            <Assessment leadData={leadData} />
          </div>
        )}
        
        <Expertise />
      </main>
      
      <Footer />
      
      {/* Lead Capture Modal */}
      <LeadCaptureModal
        isOpen={showLeadModal}
        onClose={() => setShowLeadModal(false)}
        onSubmit={handleLeadSubmit}
      />
      
      {/* Booking Modal */}
      <BookingModal
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
      />
    </div>
  );
}