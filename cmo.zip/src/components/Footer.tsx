import { Mail, Phone, Linkedin, Twitter, Facebook } from 'lucide-react';
import { Logo } from './Logo';

export function Footer() {
  return (
    <footer className="bg-secondary text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Logo size="md" />
              <span className="text-xl" style={{ fontFamily: 'var(--font-heading)' }}>Mumbai Consulting Firm</span>
            </div>
            <p className="text-gray-400">
              Helping young businesses like yours regardless of the size or scale to maximize your potential.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-primary mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#services" className="text-gray-400 hover:text-primary transition-colors">Services</a></li>
              <li><a href="#expertise" className="text-gray-400 hover:text-primary transition-colors">Expertise</a></li>
              <li><a href="#testimonials" className="text-gray-400 hover:text-primary transition-colors">Testimonials</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-primary mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Strategy Consulting</li>
              <li>Digital Transformation</li>
              <li>Operations Optimization</li>
              <li>Financial Advisory</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-primary mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-gray-400">
                <Mail size={18} className="text-primary" />
                <a href="mailto:aryanimbalkar03@gmail.com" className="hover:text-primary transition-colors">
                  aryanimbalkar03@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <Phone size={18} className="text-primary" />
                <a href="tel:+919833411578" className="hover:text-primary transition-colors">
                  +91 9833411578
                </a>
              </li>
            </ul>
            <div className="flex gap-4 mt-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Facebook size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 Mumbai Consulting Firm. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}