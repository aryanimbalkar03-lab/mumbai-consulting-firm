import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Logo } from './Logo';

interface HeaderProps {
  onGetAudit?: () => void;
  onBookNow?: () => void;
}

export function Header({ onGetAudit, onBookNow }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);

  const handleAuditClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onGetAudit) {
      onGetAudit();
    }
    setIsMenuOpen(false);
  };

  const handleNavClick = (sectionId: string) => {
    setIsMenuOpen(false);
    
    // Small delay to ensure menu closes first
    setTimeout(() => {
      const element = document.getElementById(sectionId);
      if (element) {
        const headerOffset = 80;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    }, 100);
  };

  const handleBookClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onBookNow) {
      onBookNow();
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-secondary text-white sticky top-0 z-50 shadow-lg shadow-primary/10">
      <nav className="container mx-auto px-6 py-4">
        {/* Desktop Layout */}
        <div className="hidden md:flex items-center justify-between">
          {/* Left Navigation */}
          <div className="flex items-center gap-8">
            <button 
              onClick={() => handleNavClick('home')}
              onMouseEnter={() => setHoveredButton('home')}
              onMouseLeave={() => setHoveredButton(null)}
              className="relative group transition-all duration-300"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              <span className={`transition-all duration-300 ${hoveredButton === 'home' ? 'text-primary' : 'text-white'}`}>
                {hoveredButton === 'home' ? (
                  <span className="block text-center leading-tight">
                    <span className="block text-sm">Return to main</span>
                    <span className="block text-base font-bold">landing page</span>
                    <span className="block text-sm">and hero section</span>
                  </span>
                ) : (
                  'Home'
                )}
              </span>
            </button>
            <button 
              onClick={() => handleNavClick('services')}
              onMouseEnter={() => setHoveredButton('services')}
              onMouseLeave={() => setHoveredButton(null)}
              className="relative group transition-all duration-300"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              <span className={`transition-all duration-300 ${hoveredButton === 'services' ? 'text-primary' : 'text-white'}`}>
                {hoveredButton === 'services' ? (
                  <span className="block text-center leading-tight">
                    <span className="block text-sm">Explore our complete</span>
                    <span className="block text-base font-bold">consulting services</span>
                    <span className="block text-sm">and expertise areas</span>
                  </span>
                ) : (
                  'Services'
                )}
              </span>
            </button>
          </div>

          {/* Centered Logo */}
          <button 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3"
          >
            <Logo size="md" />
            <span className="text-xl font-black tracking-tight" style={{ fontFamily: 'var(--font-heading)', fontWeight: 800 }}>MUMBAI CONSULTING FIRM</span>
          </button>

          {/* Right Navigation */}
          <div className="flex items-center gap-8">
            <button 
              onClick={() => handleNavClick('expertise')}
              onMouseEnter={() => setHoveredButton('expertise')}
              onMouseLeave={() => setHoveredButton(null)}
              className="relative group transition-all duration-300"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              <span className={`transition-all duration-300 ${hoveredButton === 'expertise' ? 'text-primary' : 'text-white'}`}>
                {hoveredButton === 'expertise' ? (
                  <span className="block text-center leading-tight">
                    <span className="block text-sm">Learn why we're</span>
                    <span className="block text-base font-bold">India's most honest</span>
                    <span className="block text-sm">consulting firm</span>
                  </span>
                ) : (
                  'Why Us'
                )}
              </span>
            </button>
            <button 
              onClick={handleAuditClick}
              onMouseEnter={() => setHoveredButton('audit')}
              onMouseLeave={() => setHoveredButton(null)}
              className="bg-primary text-white px-6 py-2 rounded hover:bg-primary-dark transition-all duration-300 font-bold min-w-[140px]" 
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {hoveredButton === 'audit' ? (
                <span className="block text-center leading-tight text-sm">
                  <span className="block">Take our free</span>
                  <span className="block font-black">3-minute test</span>
                  <span className="block">Know if you need us</span>
                </span>
              ) : (
                'Free Audit'
              )}
            </button>
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="md:hidden">
          <div className="flex items-center justify-between">
            {/* Centered Logo on Mobile */}
            <button 
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2 mx-auto"
            >
              <Logo size="sm" />
              <span className="text-base font-black" style={{ fontFamily: 'var(--font-heading)', fontWeight: 800 }}>MUMBAI CONSULTING FIRM</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              className="absolute right-6"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="mt-4 pb-4 space-y-4 animate-fadeInUp">
              <button 
                onClick={() => handleNavClick('home')}
                className="block w-full text-left hover:text-primary transition-colors"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Home
              </button>
              <button 
                onClick={() => handleNavClick('services')}
                className="block w-full text-left hover:text-primary transition-colors"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Services
              </button>
              <button 
                onClick={() => handleNavClick('expertise')}
                className="block w-full text-left hover:text-primary transition-colors"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Why Us
              </button>
              <button 
                onClick={handleAuditClick}
                className="block w-full bg-primary text-white px-6 py-3 rounded text-center hover:bg-primary-dark transition-colors font-bold" 
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Get Free Consultancy Test
              </button>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}