import { TrendingUp, TrendingDown, DollarSign, Users, Shield, FileText, Target, Lock, AlertTriangle, CheckCircle, Calendar, Zap, BarChart3, PieChart, Activity, Info, Sparkles, ChevronDown, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { PieChart as RechartsPie, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, AreaChart, Area } from 'recharts';
import { LeadData } from './LeadCaptureModal';

interface RedFlag {
  component: string;
  triggered: boolean;
  severity: 'critical' | 'high' | 'medium';
  message: string;
}

interface AssessmentResult {
  consultingNeeded: boolean;
  redFlagsCount: number;
  redFlags: RedFlag[];
  healthScore: number;
  summary: string[];
  chartData: any;
}

interface AssessmentProps {
  leadData?: LeadData;
}

// Industry benchmarks
const INDUSTRY_BENCHMARKS: Record<string, any> = {
  'E-commerce': { margin: 30, churn: 8, repeatRate: 35, cac_ltv: 0.3, avgRevGrowth: 15 },
  'SaaS': { margin: 70, churn: 5, repeatRate: 80, cac_ltv: 0.33, avgRevGrowth: 20 },
  'Restaurant': { margin: 25, churn: 15, repeatRate: 40, cac_ltv: 0.5, avgRevGrowth: 10 },
  'Retail': { margin: 35, churn: 12, repeatRate: 30, cac_ltv: 0.4, avgRevGrowth: 12 },
  'Salon': { margin: 60, churn: 10, repeatRate: 45, cac_ltv: 0.35, avgRevGrowth: 12 },
  'Consulting': { margin: 60, churn: 10, repeatRate: 70, cac_ltv: 0.25, avgRevGrowth: 18 },
  'Manufacturing': { margin: 40, churn: 5, repeatRate: 60, cac_ltv: 0.35, avgRevGrowth: 15 },
  'Agency': { margin: 50, churn: 8, repeatRate: 65, cac_ltv: 0.3, avgRevGrowth: 16 },
  'Healthcare': { margin: 35, churn: 7, repeatRate: 75, cac_ltv: 0.4, avgRevGrowth: 12 },
  'Education': { margin: 45, churn: 10, repeatRate: 60, cac_ltv: 0.35, avgRevGrowth: 14 },
  'Other': { margin: 30, churn: 10, repeatRate: 40, cac_ltv: 0.4, avgRevGrowth: 12 },
};

const Tooltip2 = ({ text }: { text: string }) => (
  <div className="group relative inline-block ml-1">
    <Info size={16} className="text-primary cursor-help" />
    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-black text-white text-xs rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all w-64 z-50">
      {text}
      <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black"></div>
    </div>
  </div>
);

export function Assessment({ leadData }: AssessmentProps) {
  const [showAssessment, setShowAssessment] = useState(true); // Auto-show when leadData exists
  const [industry, setIndustry] = useState('');
  const [benchmark, setBenchmark] = useState(INDUSTRY_BENCHMARKS['Other']);

  // Past 3 Year Revenue (REQUIRED)
  const [year1Revenue, setYear1Revenue] = useState('');
  const [year2Revenue, setYear2Revenue] = useState('');
  const [year3Revenue, setYear3Revenue] = useState('');
  
  // Component 1: Monthly Revenue (Last 6 Months) - Optional
  const [revenues, setRevenues] = useState(['', '', '', '', '', '']);
  
  // Component 2: Gross Margin
  const [currentRevenue, setCurrentRevenue] = useState('');
  const [cogs, setCogs] = useState('');
  
  // Component 3: Cashflow
  const [cashflows, setCashflows] = useState(['', '', '']);
  
  // Component 4: Customer Churn
  const [monthlyChurn, setMonthlyChurn] = useState('');
  const [repeatPurchase, setRepeatPurchase] = useState('');
  
  // Component 5: CAC vs LTV
  const [marketingSpend, setMarketingSpend] = useState('');
  const [newCustomers, setNewCustomers] = useState('');
  const [avgOrderValue, setAvgOrderValue] = useState('');
  const [purchaseFrequency, setPurchaseFrequency] = useState('');
  const [customerLifespan, setCustomerLifespan] = useState('');
  
  // Component 6: Compliance
  const [hasLegalIssues, setHasLegalIssues] = useState('no');
  const [allLicensesCurrent, setAllLicensesCurrent] = useState('yes');
  
  // Component 7: SOPs
  const [hasSalesSOP, setHasSalesSOP] = useState('no');
  const [hasOpsSOP, setHasOpsSOP] = useState('no');
  const [hasFinanceSOP, setHasFinanceSOP] = useState('no');
  
  // Component 8: Key-Person Dependency
  const [founderOperationalLoad, setFounderOperationalLoad] = useState('');
  
  // Component 9: Technology
  const [hasBackups, setHasBackups] = useState('no');
  const [systemsUpdated, setSystemsUpdated] = useState('no');
  
  // Component 10: Profitability
  const [monthsUnprofitable, setMonthsUnprofitable] = useState('');

  // NEW Component 11: Working Capital
  const [currentAssets, setCurrentAssets] = useState('');
  const [currentLiabilities, setCurrentLiabilities] = useState('');
  
  // NEW: Revenue Sources
  const [revenueSources, setRevenueSources] = useState('');
  
  const [result, setResult] = useState<AssessmentResult | null>(null);

  useEffect(() => {
    if (industry && INDUSTRY_BENCHMARKS[industry]) {
      setBenchmark(INDUSTRY_BENCHMARKS[industry]);
    }
  }, [industry]);

  const parseNumber = (value: string): number => {
    if (!value || value.toLowerCase() === 'na' || value.toLowerCase() === 'n/a') return 0;
    const clean = value.toLowerCase().replace(/[₹$€£,\s]/g, '');
    if (clean.includes('cr') || clean.includes('crore')) return parseFloat(clean.replace(/cr|crore/g, '')) * 10000000;
    if (clean.includes('l') || clean.includes('lakh') || clean.includes('lac')) return parseFloat(clean.replace(/l|lakh|lac/g, '')) * 100000;
    if (clean.includes('k')) return parseFloat(clean.replace(/k/g, '')) * 1000;
    if (clean.includes('m')) return parseFloat(clean.replace(/m/g, '')) * 1000000;
    return parseFloat(clean) || 0;
  };

  const formatCurrency = (num: number): string => {
    if (num >= 10000000) return `₹${(num / 10000000).toFixed(2)}Cr`;
    if (num >= 100000) return `₹${(num / 100000).toFixed(2)}L`;
    if (num >= 1000) return `₹${(num / 1000).toFixed(2)}K`;
    return `₹${num.toFixed(0)}`;
  };

  const runDiagnostic = () => {
    if (!industry) {
      alert('⚠️ Please select your industry first');
      return;
    }

    // Validate 3-year revenue (REQUIRED)
    const rev1 = parseNumber(year1Revenue);
    const rev2 = parseNumber(year2Revenue);
    const rev3 = parseNumber(year3Revenue);

    if (rev1 === 0) {
      alert('⚠️ Current year revenue is required. Enter "NA" if you don\'t have exact data.');
      return;
    }

    const redFlags: RedFlag[] = [];
    
    // ========== DATA TRACKING CHECK ==========
    const allInputs = [
      year1Revenue, year2Revenue, year3Revenue,
      ...revenues,
      currentRevenue, cogs,
      ...cashflows,
      monthlyChurn, repeatPurchase,
      marketingSpend, newCustomers, avgOrderValue, purchaseFrequency, customerLifespan,
      founderOperationalLoad,
      monthsUnprofitable,
      currentAssets, currentLiabilities,
      revenueSources
    ];
    
    const naCount = allInputs.filter(val => 
      typeof val === 'string' && (val.toLowerCase() === 'na' || val.toLowerCase() === 'n/a' || val.trim() === '')
    ).length;
    
    if (naCount > 2) {
      redFlags.push({
        component: 'Data Tracking & Business Intelligence',
        triggered: true,
        severity: 'critical',
        message: `${naCount} missing data points detected. You don't have proper data tracking systems - flying blind. Cannot make informed decisions without data.`,
      });
    }
    
    // ========== 3-YEAR GROWTH ANALYSIS ==========
    const revenues3yr = [rev3, rev2, rev1].filter(r => r > 0);
    if (revenues3yr.length >= 2) {
      const firstYear = revenues3yr[0];
      const lastYear = revenues3yr[revenues3yr.length - 1];
      const growthRate = ((lastYear - firstYear) / firstYear) * 100;
      
      if (growthRate < 0) {
        redFlags.push({
          component: 'Revenue Growth (3-Year)',
          triggered: true,
          severity: 'critical',
          message: `${growthRate.toFixed(1)}% decline over 3 years. Business is shrinking.`,
        });
      } else if (growthRate < benchmark.avgRevGrowth) {
        redFlags.push({
          component: 'Revenue Growth (3-Year)',
          triggered: true,
          severity: 'high',
          message: `${growthRate.toFixed(1)}% growth below ${benchmark.avgRevGrowth}% industry average. Stagnation risk.`,
        });
      }
    }
    
    // ========== COMPONENT 1: Revenue Trend (6 months) ==========
    const revValues = revenues.map(r => parseNumber(r)).filter(r => r > 0);
    if (revValues.length >= 3) {
      const last3 = revValues.slice(-3);
      if (last3.length === 3 && last3[0] > last3[1] && last3[1] > last3[2]) {
        redFlags.push({
          component: 'Monthly Revenue Trend',
          triggered: true,
          severity: 'critical',
          message: '3 consecutive months of declining revenue. Immediate action needed.',
        });
      }
    }
    
    // ========== COMPONENT 2: Gross Margin ==========
    const rev = parseNumber(currentRevenue);
    const cogsVal = parseNumber(cogs);
    let grossMargin = 0;
    if (rev > 0) {
      grossMargin = ((rev - cogsVal) / rev) * 100;
      if (grossMargin < benchmark.margin) {
        redFlags.push({
          component: 'Gross Margin',
          triggered: true,
          severity: 'critical',
          message: `${grossMargin.toFixed(1)}% below ${benchmark.margin}% industry standard. Pricing/cost crisis.`,
        });
      }
    }
    
    // ========== COMPONENT 3: Cashflow ==========
    const cfValues = cashflows.map(cf => parseNumber(cf));
    const validCF = cfValues.filter(cf => cf !== 0);
    if (validCF.length === 3) {
      const negativeCount = validCF.filter(cf => cf < 0).length;
      if (negativeCount === 3) {
        redFlags.push({
          component: 'Operating Cashflow',
          triggered: true,
          severity: 'critical',
          message: 'Negative cashflow for 3 consecutive months. Cash crisis imminent.',
        });
      }
    }
    
    // ========== COMPONENT 4: Customer Churn ==========
    const churnRate = parseFloat(monthlyChurn);
    const repeatRate = parseFloat(repeatPurchase);
    if (!isNaN(churnRate) && churnRate > benchmark.churn) {
      redFlags.push({
        component: 'Customer Churn',
        triggered: true,
        severity: 'high',
        message: `${churnRate}% churn exceeds ${benchmark.churn}% threshold. Retention crisis.`,
      });
    }
    if (!isNaN(repeatRate) && repeatRate > 0 && repeatRate < benchmark.repeatRate) {
      redFlags.push({
        component: 'Customer Loyalty',
        triggered: true,
        severity: 'high',
        message: `${repeatRate}% repeat rate below ${benchmark.repeatRate}%. Loyalty problem.`,
      });
    }
    
    // ========== COMPONENT 5: CAC vs LTV ==========
    const mktSpend = parseNumber(marketingSpend);
    const newCust = parseFloat(newCustomers);
    const aov = parseNumber(avgOrderValue);
    const freq = parseFloat(purchaseFrequency);
    const lifespan = parseFloat(customerLifespan);
    
    let cac = 0;
    let ltv = 0;
    let cacLtvRatio = 0;
    
    if (newCust > 0) cac = mktSpend / newCust;
    if (aov > 0 && freq > 0 && lifespan > 0) ltv = aov * freq * lifespan;
    if (ltv > 0 && cac > 0) cacLtvRatio = cac / ltv;
    
    if (cacLtvRatio > benchmark.cac_ltv && cac > 0 && ltv > 0) {
      redFlags.push({
        component: 'Marketing ROI (CAC/LTV)',
        triggered: true,
        severity: 'critical',
        message: `CAC ${formatCurrency(cac)} too high vs LTV ${formatCurrency(ltv)}. Unsustainable.`,
      });
    }
    
    // ========== COMPONENT 6: Compliance ==========
    if (hasLegalIssues === 'yes' || allLicensesCurrent === 'no') {
      redFlags.push({
        component: 'Legal & Compliance',
        triggered: true,
        severity: 'critical',
        message: 'Legal/compliance gaps detected. Regulatory risk high.',
      });
    }
    
    // ========== COMPONENT 7: SOPs ==========
    if (hasSalesSOP === 'no' || hasOpsSOP === 'no' || hasFinanceSOP === 'no') {
      redFlags.push({
        component: 'Process Documentation',
        triggered: true,
        severity: 'medium',
        message: 'Missing critical SOPs. Cannot scale without documented processes.',
      });
    }
    
    // ========== COMPONENT 8: Key-Person Dependency ==========
    const founderLoad = parseFloat(founderOperationalLoad);
    if (!isNaN(founderLoad) && founderLoad > 50) {
      redFlags.push({
        component: 'Founder Dependency',
        triggered: true,
        severity: 'high',
        message: `${founderLoad}% operations dependent on founder. Single point of failure.`,
      });
    }
    
    // ========== COMPONENT 9: Technology ==========
    if (hasBackups === 'no' || systemsUpdated === 'no') {
      redFlags.push({
        component: 'Technology & Security',
        triggered: true,
        severity: 'high',
        message: 'Critical tech/security gaps. Data loss/breach risk.',
      });
    }
    
    // ========== COMPONENT 10: Profitability ==========
    const unprofitableMonths = parseFloat(monthsUnprofitable);
    if (!isNaN(unprofitableMonths) && unprofitableMonths > 12) {
      redFlags.push({
        component: 'Profitability Track Record',
        triggered: true,
        severity: 'critical',
        message: `Unprofitable for ${unprofitableMonths} months. Business model broken.`,
      });
    }

    // ========== COMPONENT 11: Working Capital ==========
    const currAssets = parseNumber(currentAssets);
    const currLiab = parseNumber(currentLiabilities);
    if (currAssets > 0 && currLiab > 0) {
      const currentRatio = currAssets / currLiab;
      if (currentRatio < 1) {
        redFlags.push({
          component: 'Working Capital',
          triggered: true,
          severity: 'critical',
          message: `Current ratio ${currentRatio.toFixed(2)} below 1.0. Liquidity crisis.`,
        });
      }
    }

    // ========== REVENUE DIVERSIFICATION ==========
    const numRevenueSources = parseFloat(revenueSources);
    if (!isNaN(numRevenueSources) && numRevenueSources === 1) {
      redFlags.push({
        component: 'Revenue Diversification',
        triggered: true,
        severity: 'high',
        message: 'Single revenue source/product. Extreme concentration risk. One market shift = business collapse.',
      });
    }

    // ========== FINAL DECISION ==========
    const consultingNeeded = redFlags.length > 0;
    const healthScore = Math.max(0, 100 - (redFlags.length * 8));
    
    // ========== 5-LINE SUMMARY ==========
    const summary: string[] = [];
    
    if (consultingNeeded) {
      summary.push(`🚨 VERDICT: Your ${industry} business needs consulting NOW. ${redFlags.length} critical red flag${redFlags.length > 1 ? 's' : ''} detected.`);
      
      const criticalFlags = redFlags.filter(f => f.severity === 'critical');
      if (criticalFlags.length > 0) {
        summary.push(`⚠️ CRITICAL: ${criticalFlags.map(f => f.component).join(', ')} - these require immediate intervention to prevent business failure.`);
      }
      
      summary.push(`📊 HEALTH SCORE: ${healthScore}/100. ${healthScore < 40 ? 'Your business is in critical condition' : healthScore < 60 ? 'Significant improvements needed urgently' : 'Vulnerable - act before it\'s too late'}.`);
      
      summary.push(`💰 OPPORTUNITY: Our AI analysis shows ${redFlags.length} fixable issue${redFlags.length > 1 ? 's' : ''}. Conservative estimate: 40-80% profitability increase within 6-12 months.`);
      
      summary.push(`✅ ACTION: Book FREE consultation now. We'll create a custom 90-day turnaround roadmap. Results-driven partnership.`);
    } else {
      summary.push(`✅ EXCELLENT NEWS: Your ${industry} business passed all diagnostic checks. Consulting not needed at this time.`);
      
      summary.push(`🎯 HEALTH SCORE: ${healthScore}/100 - You're operating within healthy parameters across all key metrics.`);
      
      summary.push(`📈 STRENGTHS: Strong margins${grossMargin > 0 ? ` (${grossMargin.toFixed(1)}%)` : ''}, healthy cashflow, proper documentation, good customer retention, and solid operational foundation.`);
      
      summary.push(`💼 MAINTENANCE: Continue monthly monitoring of these metrics to catch issues early and maintain business health.`);
      
      summary.push(`🚀 GROWTH: Optional strategic consultation available if you want to 10x scale, enter new markets, or raise funding.`);
    }

    // ========== CHART DATA ==========
    // More nuanced scoring based on severity
    const getComponentScore = (componentName: string) => {
      const flag = redFlags.find(f => f.component.includes(componentName));
      if (!flag) return 100;
      if (flag.severity === 'critical') return 15;
      if (flag.severity === 'high') return 40;
      return 65; // medium
    };

    const componentScores = [
      { component: 'Revenue Growth', score: getComponentScore('Revenue') },
      { component: 'Profit Margin', score: getComponentScore('Margin') },
      { component: 'Cashflow', score: getComponentScore('Cashflow') },
      { component: 'Customer Retention', score: Math.min(getComponentScore('Churn'), getComponentScore('Loyalty')) },
      { component: 'Marketing ROI', score: getComponentScore('CAC') },
      { component: 'Legal Compliance', score: getComponentScore('Compliance') },
      { component: 'Processes & SOPs', score: getComponentScore('Process') },
      { component: 'Leadership', score: getComponentScore('Founder') },
      { component: 'Technology', score: getComponentScore('Technology') },
      { component: 'Profitability', score: getComponentScore('Profitability') },
      { component: 'Working Capital', score: getComponentScore('Working Capital') },
      { component: 'Data Tracking', score: getComponentScore('Data Tracking') },
      { component: 'Revenue Mix', score: getComponentScore('Diversification') },
    ];

    const severityBreakdown = [
      { name: 'Critical Issues', value: redFlags.filter(f => f.severity === 'critical').length, color: '#DC2626' },
      { name: 'High Priority', value: redFlags.filter(f => f.severity === 'high').length, color: '#F97316' },
      { name: 'Medium Priority', value: redFlags.filter(f => f.severity === 'medium').length, color: '#EAB308' },
      { name: 'Healthy Areas', value: Math.max(0, 13 - redFlags.length), color: '#10B981' },
    ].filter(item => item.value > 0);

    const revenue3yrData = [
      { year: '3 Yrs Ago', revenue: rev3 || 0 },
      { year: '2 Yrs Ago', revenue: rev2 || 0 },
      { year: 'Current', revenue: rev1 },
    ].filter(item => item.revenue > 0);

    // Advanced financial metrics
    const currentRatioCalc = currAssets > 0 && currLiab > 0 ? currAssets / currLiab : 0;
    const revenueGrowthRate = rev2 > 0 && rev1 > 0 ? ((rev1 - rev2) / rev2) * 100 : 0;
    const burnRate = validCF.length > 0 ? validCF.reduce((a, b) => a + b, 0) / validCF.length : 0;

    setResult({
      consultingNeeded,
      redFlagsCount: redFlags.length,
      redFlags,
      healthScore,
      summary,
      chartData: {
        components: componentScores,
        severity: severityBreakdown,
        revenue: revenue3yrData,
        metrics: {
          grossMargin,
          cac,
          ltv,
          cacLtvRatio,
          churnRate,
          repeatRate,
          currentRatio: currentRatioCalc,
          revenueGrowth: revenueGrowthRate,
          avgCashflow: burnRate,
          revenueSources: parseFloat(revenueSources) || 0,
          dataQuality: Math.round(((allInputs.length - naCount) / allInputs.length) * 100),
        },
      },
    });

    // Send complete audit data to backend
    if (leadData) {
      const auditSubmission = {
        ...leadData,
        auditData: {
          industry,
          year1Revenue,
          year2Revenue,
          year3Revenue,
          currentRevenue,
          cogs,
          grossMargin,
          cashflows,
          monthlyChurn,
          repeatPurchase,
          marketingSpend,
          newCustomers,
          avgOrderValue,
          purchaseFrequency,
          customerLifespan,
          cac,
          ltv,
          cacLtvRatio,
          hasLegalIssues,
          allLicensesCurrent,
          hasSalesSOP,
          hasOpsSOP,
          hasFinanceSOP,
          founderOperationalLoad,
          hasBackups,
          systemsUpdated,
          monthsUnprofitable,
          currentAssets,
          currentLiabilities,
          currentRatio: currentRatioCalc,
          revenueSources,
          revenueGrowth: revenueGrowthRate,
        },
        results: {
          consultingNeeded,
          redFlagsCount: redFlags.length,
          redFlags,
          healthScore,
        },
        timestamp: new Date().toISOString(),
      };

      // Send to backend API
      fetch('/api/audit-submission', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(auditSubmission),
      }).catch(err => {
        console.error('Failed to send audit data:', err);
      });
    }

    // Scroll to results
    setTimeout(() => {
      const resultsEl = document.getElementById('results');
      if (resultsEl) {
        resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  if (!showAssessment) {
    return (
      <section id="assessment" className="py-32 bg-gradient-to-br from-black via-primary/5 to-black text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'repeating-linear-gradient(45deg, #FF1493 0px, #FF1493 2px, transparent 2px, transparent 10px)',
          }}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="mb-8">
              <Sparkles className="mx-auto text-primary mb-4" size={64} />
              <h2 className="text-6xl md:text-8xl mb-6 tracking-tight">
                <span className="block text-primary">FREE</span>
                <span className="block">BUSINESS AUDIT</span>
              </h2>
              <p className="text-2xl md:text-3xl text-gray-300 mb-6">
                AI-Powered • 11-Point Diagnostic • Industry-Specific Analysis
              </p>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Find out in 3 minutes if your business needs consulting. 100% honest results. 
                If you don't need us, we'll tell you.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-lg border border-primary/30 rounded-2xl p-8 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-5xl mb-3">⚡</div>
                  <div className="text-primary text-xl mb-2">3-Minute Analysis</div>
                  <div className="text-gray-400 text-sm">Quick, simple, powerful</div>
                </div>
                <div className="text-center">
                  <div className="text-5xl mb-3">🎯</div>
                  <div className="text-primary text-xl mb-2">100% Accurate</div>
                  <div className="text-gray-400 text-sm">11-component deep scan</div>
                </div>
                <div className="text-center">
                  <div className="text-5xl mb-3">💯</div>
                  <div className="text-primary text-xl mb-2">Honest Verdict</div>
                  <div className="text-gray-400 text-sm">We only help if needed</div>
                </div>
              </div>

              <div className="space-y-3 text-left max-w-xl mx-auto mb-8">
                <div className="flex items-center gap-3 text-gray-300">
                  <CheckCircle className="text-primary flex-shrink-0" size={20} />
                  <span>Auto-calculates complex metrics (CAC, LTV, Growth Rate, Margins)</span>
                </div>
                <div className="flex items-center gap-3 text-gray-300">
                  <CheckCircle className="text-primary flex-shrink-0" size={20} />
                  <span>Industry-specific benchmarks (SaaS, E-commerce, Retail, etc.)</span>
                </div>
                <div className="flex items-center gap-3 text-gray-300">
                  <CheckCircle className="text-primary flex-shrink-0" size={20} />
                  <span>Enter "NA" for data you don't have - we work with what you've got</span>
                </div>
                <div className="flex items-center gap-3 text-gray-300">
                  <CheckCircle className="text-primary flex-shrink-0" size={20} />
                  <span>Visual charts & professional report at the end</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowAssessment(true)}
              className="bg-primary text-black px-16 py-6 rounded-lg hover:opacity-90 transition-all text-3xl md:text-4xl transform hover:scale-105 inline-flex items-center gap-4 shadow-2xl"
            >
              <Zap size={40} />
              START FREE AUDIT NOW
              <ChevronDown size={40} />
            </button>
            
            <p className="mt-6 text-gray-500 text-sm">
              No credit card • No signup • Results in 3 minutes
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="assessment" className="py-20 bg-gradient-to-br from-black via-gray-900 to-black text-white relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'repeating-linear-gradient(45deg, #FF1493 0px, #FF1493 2px, transparent 2px, transparent 10px)',
        }}></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          
          {/* Close button */}
          <div className="flex justify-end mb-4">
            <button
              onClick={() => setShowAssessment(false)}
              className="text-gray-400 hover:text-primary transition-colors flex items-center gap-2"
            >
              <X size={24} />
              <span>Close Audit</span>
            </button>
          </div>

          {/* Header */}
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-6xl mb-6 tracking-tight">
              <span className="block text-primary">11-POINT DIAGNOSTIC</span>
              <span className="block text-2xl md:text-3xl text-gray-400 mt-2">AI-Powered Business Health Check</span>
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              Answer what you know. Enter "NA" for what you don't. We'll work with your data.
            </p>
          </div>

          {/* Industry Selector */}
          <div className="bg-gradient-to-r from-primary/20 to-primary/5 border-2 border-primary rounded-xl p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Target className="text-primary" size={28} />
              <h3 className="text-2xl text-primary">Step 1: Select Your Industry</h3>
              <Tooltip2 text="We'll compare your metrics against industry-specific benchmarks for accurate analysis" />
            </div>
            <select
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              className="w-full px-6 py-4 bg-black/50 border-2 border-white/30 rounded-lg focus:border-primary focus:outline-none text-white text-xl"
              required
            >
              <option value="">-- Choose Your Industry --</option>
              {Object.keys(INDUSTRY_BENCHMARKS).map(ind => (
                <option key={ind} value={ind}>{ind}</option>
              ))}
            </select>
            {industry && (
              <div className="mt-4 p-4 bg-black/40 rounded-lg">
                <p className="text-sm text-gray-300">
                  <strong className="text-primary">{industry} Benchmarks:</strong> Margin {benchmark.margin}% • Churn {benchmark.churn}% • Repeat {benchmark.repeatRate}%
                </p>
              </div>
            )}
          </div>

          {/* Main Form */}
          {industry && (
            <div className="space-y-6">
              
              {/* REQUIRED: 3-Year Revenue */}
              <div className="bg-gradient-to-r from-red-500/20 to-primary/10 border-2 border-red-500 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <TrendingUp className="text-red-500" size={28} />
                  <h3 className="text-2xl text-red-500">REQUIRED: Past 3 Years Revenue</h3>
                  <Tooltip2 text="This is critical for growth analysis. We need at least current year revenue." />
                </div>
                <p className="text-gray-300 mb-4 text-sm">Enter at least current year. Type "NA" if you don't have exact past data.</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-white mb-2">Current Year Revenue *</label>
                    <input
                      type="text"
                      value={year1Revenue}
                      onChange={(e) => setYear1Revenue(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹ 50L or NA"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-white mb-2">Last Year Revenue</label>
                    <input
                      type="text"
                      value={year2Revenue}
                      onChange={(e) => setYear2Revenue(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹ 40L or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-white mb-2">2 Years Ago Revenue</label>
                    <input
                      type="text"
                      value={year3Revenue}
                      onChange={(e) => setYear3Revenue(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹ 30L or NA"
                    />
                  </div>
                </div>
              </div>

              {/* Component 2: Gross Margin */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <DollarSign className="text-primary" size={24} />
                  <h3 className="text-xl">Gross Margin</h3>
                  <Tooltip2 text="COGS = Cost of Goods Sold. Total cost to produce/deliver your product/service." />
                  <span className="ml-auto text-xs text-gray-400">Red Flag: {'<'}{benchmark.margin}%</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Current Revenue</label>
                    <input
                      type="text"
                      value={currentRevenue}
                      onChange={(e) => setCurrentRevenue(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹10L or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">COGS (Cost of Goods Sold)</label>
                    <input
                      type="text"
                      value={cogs}
                      onChange={(e) => setCogs(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹6L or NA"
                    />
                  </div>
                  <div className="bg-primary/20 border-2 border-primary rounded-lg p-3 flex flex-col justify-center">
                    <label className="text-primary text-sm mb-1">Margin (Auto)</label>
                    <div className="text-2xl text-white">
                      {currentRevenue && cogs && parseNumber(currentRevenue) > 0
                        ? `${(((parseNumber(currentRevenue) - parseNumber(cogs)) / parseNumber(currentRevenue)) * 100).toFixed(1)}%`
                        : 'N/A'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Component 3: Cashflow */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Activity className="text-primary" size={24} />
                  <h3 className="text-xl">Operating Cashflow (Last 3 Months)</h3>
                  <Tooltip2 text="Money in minus money out each month. Use minus (-) for losses." />
                  <span className="ml-auto text-xs text-gray-400">Red Flag: 3 consecutive negatives</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {cashflows.map((cf, idx) => (
                    <input
                      key={idx}
                      type="text"
                      placeholder={`Month ${idx + 1} (e.g., -2L or 3L or NA)`}
                      value={cf}
                      onChange={(e) => {
                        const newCFs = [...cashflows];
                        newCFs[idx] = e.target.value;
                        setCashflows(newCFs);
                      }}
                      className="px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white text-center placeholder-gray-500"
                    />
                  ))}
                </div>
              </div>

              {/* Component 4: Customer Metrics */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Users className="text-primary" size={24} />
                  <h3 className="text-xl">Customer Retention</h3>
                  <Tooltip2 text="Churn = % customers lost monthly. Repeat = % who buy again." />
                  <span className="ml-auto text-xs text-gray-400">Red Flag: Churn {'>'}{benchmark.churn}% or Repeat {'<'}{benchmark.repeatRate}%</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Monthly Churn Rate (%) or NA</label>
                    <input
                      type="text"
                      value={monthlyChurn}
                      onChange={(e) => setMonthlyChurn(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="8 or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Repeat Purchase Rate (%) or NA</label>
                    <input
                      type="text"
                      value={repeatPurchase}
                      onChange={(e) => setRepeatPurchase(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="40 or NA"
                    />
                  </div>
                </div>
              </div>

              {/* Component 5: CAC vs LTV */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <BarChart3 className="text-primary" size={24} />
                  <h3 className="text-xl">Marketing Efficiency</h3>
                  <Tooltip2 text="CAC = Customer Acquisition Cost. LTV = Lifetime Value. CAC should be much lower than LTV." />
                  <span className="ml-auto text-xs text-gray-400">Red Flag: CAC {'>'} LTV</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Monthly Marketing Spend</label>
                    <input
                      type="text"
                      value={marketingSpend}
                      onChange={(e) => setMarketingSpend(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹2L or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">New Customers/Month</label>
                    <input
                      type="text"
                      value={newCustomers}
                      onChange={(e) => setNewCustomers(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="50 or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Avg Order Value</label>
                    <input
                      type="text"
                      value={avgOrderValue}
                      onChange={(e) => setAvgOrderValue(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹5000 or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Purchases/Year</label>
                    <input
                      type="text"
                      value={purchaseFrequency}
                      onChange={(e) => setPurchaseFrequency(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="4 or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Customer Lifespan (Years)</label>
                    <input
                      type="text"
                      value={customerLifespan}
                      onChange={(e) => setCustomerLifespan(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="3 or NA"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-primary/20 border-2 border-primary rounded-lg p-4">
                    <div className="text-primary text-sm mb-1">CAC (Auto)</div>
                    <div className="text-2xl text-white">
                      {marketingSpend && newCustomers && parseNumber(marketingSpend) > 0 && parseFloat(newCustomers) > 0
                        ? formatCurrency(parseNumber(marketingSpend) / parseFloat(newCustomers))
                        : 'N/A'}
                    </div>
                  </div>
                  <div className="bg-primary/20 border-2 border-primary rounded-lg p-4">
                    <div className="text-primary text-sm mb-1">LTV (Auto)</div>
                    <div className="text-2xl text-white">
                      {avgOrderValue && purchaseFrequency && customerLifespan &&
                       parseNumber(avgOrderValue) > 0 && parseFloat(purchaseFrequency) > 0 && parseFloat(customerLifespan) > 0
                        ? formatCurrency(parseNumber(avgOrderValue) * parseFloat(purchaseFrequency) * parseFloat(customerLifespan))
                        : 'N/A'}
                    </div>
                  </div>
                  <div className="bg-primary/20 border-2 border-primary rounded-lg p-4">
                    <div className="text-primary text-sm mb-1">CAC/LTV Ratio</div>
                    <div className="text-2xl text-white">
                      {(() => {
                        const c = marketingSpend && newCustomers && parseNumber(marketingSpend) > 0 && parseFloat(newCustomers) > 0
                          ? parseNumber(marketingSpend) / parseFloat(newCustomers) : 0;
                        const l = avgOrderValue && purchaseFrequency && customerLifespan &&
                          parseNumber(avgOrderValue) > 0 && parseFloat(purchaseFrequency) > 0 && parseFloat(customerLifespan) > 0
                          ? parseNumber(avgOrderValue) * parseFloat(purchaseFrequency) * parseFloat(customerLifespan) : 0;
                        return l > 0 && c > 0 ? (c / l).toFixed(2) : 'N/A';
                      })()}
                    </div>
                  </div>
                </div>
              </div>

              {/* Component 11: Working Capital */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <PieChart className="text-primary" size={24} />
                  <h3 className="text-xl">Working Capital / Liquidity</h3>
                  <Tooltip2 text="Current Assets = Cash + Inventory + Receivables. Current Liabilities = Short-term debts." />
                  <span className="ml-auto text-xs text-gray-400">Red Flag: Ratio {'<'} 1.0</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Current Assets</label>
                    <input
                      type="text"
                      value={currentAssets}
                      onChange={(e) => setCurrentAssets(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹30L or NA"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Current Liabilities</label>
                    <input
                      type="text"
                      value={currentLiabilities}
                      onChange={(e) => setCurrentLiabilities(e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                      placeholder="₹15L or NA"
                    />
                  </div>
                  <div className="bg-primary/20 border-2 border-primary rounded-lg p-3 flex flex-col justify-center">
                    <label className="text-primary text-sm mb-1">Current Ratio (Auto)</label>
                    <div className="text-2xl text-white">
                      {currentAssets && currentLiabilities && parseNumber(currentAssets) > 0 && parseNumber(currentLiabilities) > 0
                        ? (parseNumber(currentAssets) / parseNumber(currentLiabilities)).toFixed(2)
                        : 'N/A'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Revenue Sources */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <BarChart3 className="text-primary" size={24} />
                  <h3 className="text-xl">Revenue Diversification</h3>
                  <Tooltip2 text="How many different revenue streams/products/services do you have? More = less risk." />
                  <span className="ml-auto text-xs text-gray-400">Red Flag: 1 source (High concentration risk)</span>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Number of Revenue Sources/Products</label>
                  <input
                    type="text"
                    value={revenueSources}
                    onChange={(e) => setRevenueSources(e.target.value)}
                    className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white placeholder-gray-500"
                    placeholder="e.g., 3 or NA"
                  />
                  <p className="text-xs text-gray-500 mt-2">1 = Single product/service, 2+ = Diversified</p>
                </div>
              </div>

              {/* Component 6-10: Quick Yes/No */}
              <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-xl p-6">
                <h3 className="text-xl text-primary mb-6">Quick Checks (Yes/No)</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="text-primary" size={20} />
                      <label className="text-white">Any legal issues/missing licenses?</label>
                      <Tooltip2 text="Pending lawsuits, expired licenses, compliance violations" />
                    </div>
                    <select
                      value={hasLegalIssues === 'yes' || allLicensesCurrent === 'no' ? 'yes' : 'no'}
                      onChange={(e) => {
                        setHasLegalIssues(e.target.value);
                        setAllLicensesCurrent(e.target.value === 'yes' ? 'no' : 'yes');
                      }}
                      className="w-full px-4 py-2 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white"
                    >
                      <option value="no">No</option>
                      <option value="yes">Yes</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="text-primary" size={20} />
                      <label className="text-white">Missing SOPs (Sales/Ops/Finance)?</label>
                      <Tooltip2 text="SOP = Standard Operating Procedure. Documented process guides." />
                    </div>
                    <select
                      value={hasSalesSOP === 'no' || hasOpsSOP === 'no' || hasFinanceSOP === 'no' ? 'yes' : 'no'}
                      onChange={(e) => {
                        const val = e.target.value === 'yes' ? 'no' : 'yes';
                        setHasSalesSOP(val);
                        setHasOpsSOP(val);
                        setHasFinanceSOP(val);
                      }}
                      className="w-full px-4 py-2 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white"
                    >
                      <option value="no">No (We have SOPs)</option>
                      <option value="yes">Yes (Missing SOPs)</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="text-primary" size={20} />
                      <label className="text-white">Founder handles {'>'}50% of operations?</label>
                      <Tooltip2 text="High dependency on one person is a major business risk" />
                    </div>
                    <select
                      value={parseFloat(founderOperationalLoad) > 50 ? 'yes' : 'no'}
                      onChange={(e) => setFounderOperationalLoad(e.target.value === 'yes' ? '75' : '30')}
                      className="w-full px-4 py-2 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white"
                    >
                      <option value="no">No (Well-delegated)</option>
                      <option value="yes">Yes (Founder-dependent)</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Lock className="text-primary" size={20} />
                      <label className="text-white">Missing backups or outdated systems?</label>
                      <Tooltip2 text="No data backups or systems not updated in 1+ year" />
                    </div>
                    <select
                      value={hasBackups === 'no' || systemsUpdated === 'no' ? 'yes' : 'no'}
                      onChange={(e) => {
                        const val = e.target.value === 'yes' ? 'no' : 'yes';
                        setHasBackups(val);
                        setSystemsUpdated(val);
                      }}
                      className="w-full px-4 py-2 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white"
                    >
                      <option value="no">No (All good)</option>
                      <option value="yes">Yes (Tech gaps)</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingDown className="text-primary" size={20} />
                      <label className="text-white">Unprofitable for {'>'}12 months?</label>
                      <Tooltip2 text="Continuous losses for over a year" />
                    </div>
                    <select
                      value={parseFloat(monthsUnprofitable) > 12 ? 'yes' : 'no'}
                      onChange={(e) => setMonthsUnprofitable(e.target.value === 'yes' ? '15' : '0')}
                      className="w-full px-4 py-2 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none text-white"
                    >
                      <option value="no">No (Profitable or {'<'}12mo)</option>
                      <option value="yes">Yes ({'>'} 12 months loss)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Run Button */}
              <button
                onClick={runDiagnostic}
                className="w-full bg-primary text-black px-8 py-6 rounded-lg hover:opacity-90 transition-all text-3xl md:text-4xl transform hover:scale-[1.02] flex items-center justify-center gap-3 shadow-2xl"
              >
                <Zap size={40} />
                GET MY RESULTS NOW
              </button>
            </div>
          )}

          {/* Results */}
          {result && (
            <div id="results" className="mt-16 space-y-8 scroll-mt-20">
              
              {/* Main Result Card */}
              <div className={`backdrop-blur-lg border-4 rounded-2xl p-10 text-center shadow-2xl ${
                result.consultingNeeded ? 'bg-red-500/20 border-red-500' : 'bg-green-500/20 border-green-500'
              }`}>
                <div className="mb-6">
                  {result.consultingNeeded 
                    ? <AlertTriangle className="text-red-500 mx-auto animate-pulse" size={100} />
                    : <CheckCircle className="text-green-500 mx-auto" size={100} />
                  }
                </div>
                <div className="text-7xl md:text-8xl mb-4 font-black">{result.healthScore}/100</div>
                <div className="text-3xl md:text-5xl mb-6 font-black">
                  {result.consultingNeeded ? '⚠️ CONSULTING REQUIRED' : '✅ YOU\'RE DOING GREAT'}
                </div>
                <div className="text-xl md:text-2xl text-gray-200">
                  {result.redFlagsCount} Critical Issue{result.redFlagsCount !== 1 ? 's' : ''} Detected
                </div>
              </div>

              {/* Red Flags */}
              {result.redFlags.length > 0 && (
                <div className="bg-white/5 backdrop-blur-lg border-2 border-red-500 rounded-2xl p-8">
                  <h3 className="text-3xl md:text-4xl text-red-500 mb-6 font-black flex items-center gap-3">
                    <AlertTriangle size={36} />
                    Issues Found
                  </h3>
                  <div className="space-y-4">
                    {result.redFlags.map((flag, idx) => (
                      <div key={idx} className={`p-5 rounded-lg border-2 ${
                        flag.severity === 'critical' ? 'bg-red-500/20 border-red-500' :
                        flag.severity === 'high' ? 'bg-orange-500/20 border-orange-500' :
                        'bg-yellow-500/20 border-yellow-500'
                      }`}>
                        <div className="flex items-start gap-3">
                          <AlertTriangle size={24} className={
                            flag.severity === 'critical' ? 'text-red-500' :
                            flag.severity === 'high' ? 'text-orange-500' : 'text-yellow-500'
                          } />
                          <div className="flex-1">
                            <div className="text-xl font-black mb-2">{flag.component}</div>
                            <div className="text-gray-200 text-lg">{flag.message}</div>
                          </div>
                          <div className={`px-3 py-1 rounded text-xs uppercase ${
                            flag.severity === 'critical' ? 'bg-red-500 text-white' :
                            flag.severity === 'high' ? 'bg-orange-500 text-white' :
                            'bg-yellow-500 text-black'
                          }`}>
                            {flag.severity}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Key Metrics Dashboard */}
              <div className="bg-gradient-to-br from-primary/10 to-black/40 border-2 border-primary/30 rounded-2xl p-8">
                <h3 className="text-3xl text-primary mb-6 font-black">📊 Calculated Metrics</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {result.chartData.metrics.grossMargin > 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-blue-500">
                      <div className="text-sm text-gray-400 mb-1">Gross Margin</div>
                      <div className="text-3xl text-white">{result.chartData.metrics.grossMargin.toFixed(1)}%</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.grossMargin >= benchmark.margin ? '✅ Healthy' : '⚠️ Below target'}
                      </div>
                    </div>
                  )}
                  
                  {result.chartData.metrics.cac > 0 && result.chartData.metrics.ltv > 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-green-500">
                      <div className="text-sm text-gray-400 mb-1">CAC / LTV Ratio</div>
                      <div className="text-3xl text-white">{result.chartData.metrics.cacLtvRatio.toFixed(2)}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.cacLtvRatio <= benchmark.cac_ltv ? '✅ Profitable' : '⚠️ Unsustainable'}
                      </div>
                    </div>
                  )}
                  
                  {result.chartData.metrics.currentRatio > 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-purple-500">
                      <div className="text-sm text-gray-400 mb-1">Current Ratio</div>
                      <div className="text-3xl text-white">{result.chartData.metrics.currentRatio.toFixed(2)}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.currentRatio >= 1 ? '✅ Liquid' : '⚠️ Liquidity risk'}
                      </div>
                    </div>
                  )}
                  
                  {result.chartData.metrics.revenueGrowth !== 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-yellow-500">
                      <div className="text-sm text-gray-400 mb-1">YoY Revenue Growth</div>
                      <div className={`text-3xl ${result.chartData.metrics.revenueGrowth > 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {result.chartData.metrics.revenueGrowth > 0 ? '+' : ''}{result.chartData.metrics.revenueGrowth.toFixed(1)}%
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.revenueGrowth > benchmark.avgRevGrowth ? '✅ Strong' : '⚠️ Weak'}
                      </div>
                    </div>
                  )}
                  
                  {result.chartData.metrics.churnRate > 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-red-500">
                      <div className="text-sm text-gray-400 mb-1">Monthly Churn Rate</div>
                      <div className="text-3xl text-white">{result.chartData.metrics.churnRate}%</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.churnRate <= benchmark.churn ? '✅ Acceptable' : '⚠️ High'}
                      </div>
                    </div>
                  )}
                  
                  {result.chartData.metrics.repeatRate > 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-pink-500">
                      <div className="text-sm text-gray-400 mb-1">Repeat Purchase Rate</div>
                      <div className="text-3xl text-white">{result.chartData.metrics.repeatRate}%</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.repeatRate >= benchmark.repeatRate ? '✅ Strong loyalty' : '⚠️ Low retention'}
                      </div>
                    </div>
                  )}
                  
                  {result.chartData.metrics.revenueSources > 0 && (
                    <div className="bg-black/50 rounded-lg p-4 border-l-4 border-cyan-500">
                      <div className="text-sm text-gray-400 mb-1">Revenue Sources</div>
                      <div className="text-3xl text-white">{result.chartData.metrics.revenueSources}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.chartData.metrics.revenueSources > 1 ? '✅ Diversified' : '⚠️ Concentrated'}
                      </div>
                    </div>
                  )}
                  
                  <div className="bg-black/50 rounded-lg p-4 border-l-4 border-orange-500">
                    <div className="text-sm text-gray-400 mb-1">Data Quality Score</div>
                    <div className="text-3xl text-white">{result.chartData.metrics.dataQuality}%</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {result.chartData.metrics.dataQuality >= 80 ? '✅ Excellent tracking' : result.chartData.metrics.dataQuality >= 60 ? '⚠️ Fair tracking' : '❌ Poor tracking'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6">
                  <h4 className="text-2xl text-primary mb-4 font-black">Business Health Radar</h4>
                  <ResponsiveContainer width="100%" height={400}>
                    <RadarChart data={result.chartData.components}>
                      <PolarGrid stroke="#444" />
                      <PolarAngleAxis dataKey="component" stroke="#999" />
                      <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#999" />
                      <Radar name="Score" dataKey="score" stroke="#FF1493" fill="#FF1493" fillOpacity={0.6} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6">
                  <h4 className="text-2xl text-primary mb-4 font-black">Severity Breakdown</h4>
                  <ResponsiveContainer width="100%" height={400}>
                    <RechartsPie>
                      <Pie
                        data={result.chartData.severity}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={(entry) => entry.value > 0 ? `${entry.name}: ${entry.value}` : ''}
                        outerRadius={120}
                        dataKey="value"
                      >
                        {result.chartData.severity.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #FF1493' }} />
                    </RechartsPie>
                  </ResponsiveContainer>
                </div>

                {result.chartData.revenue.length > 0 && (
                  <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 lg:col-span-2">
                    <h4 className="text-2xl text-primary mb-4 font-black">3-Year Revenue Trend</h4>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={result.chartData.revenue}>
                        <defs>
                          <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#FF1493" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#FF1493" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                        <XAxis dataKey="year" stroke="#999" />
                        <YAxis stroke="#999" />
                        <Tooltip contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #FF1493' }} />
                        <Area type="monotone" dataKey="revenue" stroke="#FF1493" fillOpacity={1} fill="url(#colorRev)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Summary */}
              <div className="bg-gradient-to-br from-primary/20 to-primary/5 border-4 border-primary rounded-2xl p-10 shadow-2xl">
                <h3 className="text-4xl md:text-5xl text-primary mb-8 text-center font-black">📋 FINAL VERDICT</h3>
                <div className="space-y-6">
                  {result.summary.map((line, idx) => (
                    <p key={idx} className="text-xl md:text-2xl text-white leading-relaxed border-l-4 border-primary pl-6">
                      {line}
                    </p>
                  ))}
                </div>
              </div>

              {/* CTA */}
              {result.consultingNeeded && (
                <div className="text-center bg-black/40 rounded-2xl p-10">
                  <h4 className="text-3xl md:text-4xl mb-6 font-black">Ready to Fix Your Business?</h4>
                  <a
                    href="mailto:aryanimbalkar03@gmail.com?subject=FREE Consultation - Business Audit Results&body=Hi Mumbai Consulting,%0D%0A%0D%0AI just completed your 11-point diagnostic and my business needs help. My health score is [SCORE]/100.%0D%0A%0D%0APlease send me the consultation details.%0D%0A%0D%0AThank you!"
                    className="inline-block bg-primary text-black px-12 py-6 rounded-lg hover:opacity-90 transition-all text-2xl md:text-3xl transform hover:scale-105 font-black shadow-2xl"
                  >
                    📅 BOOK FREE CONSULTATION NOW
                  </a>
                  <p className="mt-6 text-gray-400 text-lg">
                    📧 aryanimbalkar03@gmail.com • 📞 +91 9833411578
                  </p>
                  <p className="mt-4 text-gray-500">
                    100% FREE consultation • No commitments • We only work with you if it makes sense
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
