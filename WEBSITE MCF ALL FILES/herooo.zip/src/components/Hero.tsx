import { ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { useEffect, useState } from 'react';

interface HeroProps {
  onGetAudit?: () => void;
  onBookNow?: () => void;
}

export function Hero({ onGetAudit, onBookNow }: HeroProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleAuditClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onGetAudit) {
      onGetAudit();
    }
  };

  const handleBookClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onBookNow) {
      onBookNow();
    }
  };

  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-black via-gray-900 to-black"
      style={{
        transform: `translateY(${scrollY * 0.3}px)`,
      }}
    >
      {/* Clean gradient background with subtle mouse tracking */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            background: `radial-gradient(circle 600px at ${mousePosition.x}px ${mousePosition.y}px, #FF1493, transparent)`,
            transition: 'background 0.5s ease',
          }}
        />
      </div>

      {/* Minimal geometric accents */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-16 h-16 border-2 border-primary/20 rounded-lg animate-float-slow" />
        <div className="absolute bottom-40 right-20 w-20 h-20 border-2 border-primary/20 rounded-full animate-float-reverse" />
        <div className="absolute top-1/2 left-1/4 w-12 h-12 bg-primary/5 rounded-full animate-pulse-slow" />
      </div>

      <div className="container mx-auto px-6 py-20 md:py-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8 text-white">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-primary/10 border-2 border-primary rounded-full backdrop-blur-sm animate-slideInLeft">
              <Sparkles className="w-5 h-5 text-primary animate-pulse" />
              <span className="text-primary tracking-wider font-bold" style={{ fontFamily: 'var(--font-heading)' }}>INDIA'S MOST HONEST CONSULTING</span>
            </div>

            {/* Headline */}
            <h1 className="animate-slideInLeft" style={{ animationDelay: '0.1s', fontFamily: 'var(--font-heading)' }}>
              <span className="block mb-3 text-5xl md:text-6xl lg:text-7xl font-black leading-[1.1] tracking-tight">TRANSFORM</span>
              <span className="block mb-3 text-5xl md:text-6xl lg:text-7xl font-black leading-[1.1] tracking-tight">YOUR BUSINESS</span>
              <span className="block text-5xl md:text-6xl lg:text-7xl font-black leading-[1.1] tracking-tight bg-gradient-to-r from-primary via-pink-400 to-primary bg-clip-text text-transparent animate-gradient-x">
                WITH EXPERTS
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-xl md:text-2xl text-gray-300 leading-relaxed animate-slideInLeft" style={{ animationDelay: '0.2s', fontFamily: 'var(--font-heading)' }}>
              Helping young businesses <span className="text-primary font-bold">maximize potential</span> through data-driven strategies
            </p>

            {/* Bold Bullet Points - WHY TAKE THE TEST */}
            <div className="space-y-4 animate-slideInLeft" style={{ animationDelay: '0.3s' }}>
              <h3 className="text-2xl md:text-3xl font-black text-primary mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                WHY TAKE OUR FREE TEST?
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <p className="text-lg text-gray-200" style={{ fontFamily: 'var(--font-heading)' }}>
                    <span className="font-bold text-white">Know if you actually need consulting</span> — 80% don't
                  </p>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <p className="text-lg text-gray-200" style={{ fontFamily: 'var(--font-heading)' }}>
                    <span className="font-bold text-white">Only 3 minutes</span> — Instant profit leak diagnosis
                  </p>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <p className="text-lg text-gray-200" style={{ fontFamily: 'var(--font-heading)' }}>
                    <span className="font-bold text-white">100% honest</span> — We'll tell you if you don't need us
                  </p>
                </div>
                
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <p className="text-lg text-gray-200" style={{ fontFamily: 'var(--font-heading)' }}>
                    <span className="font-bold text-white">Free clarity</span> — Discover what's holding you back
                  </p>
                </div>
              </div>
            </div>

            {/* PRIMARY CTA - Take the Test */}
            <div className="space-y-5 animate-slideInLeft" style={{ animationDelay: '0.4s' }}>
              <button
                onClick={handleAuditClick}
                className="group relative w-full"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-primary via-pink-500 to-primary rounded-xl blur-lg opacity-75 group-hover:opacity-100 animate-pulse-slow transition-opacity" />
                <div className="relative bg-gradient-to-r from-primary to-pink-600 px-10 py-5 rounded-xl flex items-center justify-center gap-3 transform hover:scale-105 transition-all duration-300 shadow-2xl select-none">
                  <Sparkles className="w-7 h-7 animate-spin-slow" />
                  <span className="text-xl md:text-2xl font-black text-white tracking-wide" style={{ fontFamily: 'var(--font-heading)' }}>
                    GET FREE CONSULTANCY TEST
                  </span>
                  <ArrowRight className="w-7 h-7 group-hover:translate-x-2 transition-transform" />
                </div>
              </button>

              {/* SECONDARY CTA - Book Audit */}
              <button
                onClick={handleBookClick}
                className="group relative w-full"
              >
                <div className="absolute inset-0 bg-primary rounded-xl blur-md opacity-30 group-hover:opacity-50 transition-opacity" />
                <div className="relative bg-black border-2 border-primary px-8 py-4 rounded-xl flex items-center justify-center gap-3 transform hover:scale-105 transition-all duration-300 shadow-2xl hover:bg-primary/10 select-none">
                  <span className="text-lg font-black text-primary tracking-wide" style={{ fontFamily: 'var(--font-heading)' }}>
                    📅 BOOK FREE AUDIT SESSION
                  </span>
                </div>
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center gap-6 text-gray-400 animate-slideInLeft" style={{ animationDelay: '0.5s', fontFamily: 'var(--font-heading)' }}>
              {[
                { icon: '✓', text: 'No credit card' },
                { icon: '✓', text: '3 minutes' },
                { icon: '✓', text: '100% honest' }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-2 group">
                  <div className="w-6 h-6 rounded-full bg-green-500/20 border-2 border-green-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span className="text-green-500 text-sm font-bold">{item.icon}</span>
                  </div>
                  <span className="group-hover:text-white transition-colors">{item.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column - MCF Logo */}
          <div className="relative flex items-center justify-center animate-slideInRight">
            {/* Subtle glow effect */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-slow" />
            </div>

            {/* Logo Container */}
            <div className="relative group">
              {/* Rotating border effect */}
              <div className="absolute -inset-4 bg-gradient-to-r from-primary via-pink-500 to-primary rounded-3xl opacity-30 blur-xl group-hover:opacity-50 transition-all animate-spin-very-slow" />
              
              {/* Main Logo Box */}
              <div className="relative bg-gradient-to-br from-black via-gray-900 to-black border-4 border-primary rounded-3xl p-12 transform hover:scale-105 transition-transform duration-500 shadow-2xl">
                {/* Top accent */}
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full" />
                
                {/* MCF Text */}
                <div className="relative">
                  <div 
                    className="text-9xl md:text-[12rem] font-black bg-gradient-to-br from-primary via-pink-400 to-primary bg-clip-text text-transparent tracking-tighter mb-6 animate-gradient-x"
                    style={{
                      fontFamily: 'var(--font-heading)',
                      letterSpacing: '-0.05em',
                    }}
                  >
                    MCF
                  </div>
                  
                  {/* Underline */}
                  <div className="h-1.5 w-full bg-gradient-to-r from-transparent via-primary to-transparent rounded-full mb-6" />
                </div>

                {/* Bottom accent */}
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-32 h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full" />
              </div>

              {/* Company Name */}
              <div className="mt-8 text-center space-y-3">
                <div 
                  className="text-2xl md:text-3xl font-black text-white tracking-wider"
                  style={{ 
                    fontFamily: 'var(--font-heading)',
                    fontWeight: 800
                  }}
                >
                  MUMBAI CONSULTING FIRM
                </div>
                <div className="text-lg md:text-xl text-primary font-bold tracking-wider" style={{ fontFamily: 'var(--font-heading)' }}>
                  WE ONLY WIN WHEN YOU WIN
                </div>
              </div>

              {/* Trust Badges */}
              <div className="mt-8 flex items-center justify-center gap-6 flex-wrap" style={{ fontFamily: 'var(--font-heading)' }}>
                {[
                  { color: 'green', label: 'Available Now' },
                  { color: 'primary', label: 'Mumbai Based' },
                  { color: 'blue', label: 'AI-Powered' }
                ].map((badge, idx) => (
                  <div key={idx} className="flex items-center gap-2 group">
                    <div className={`w-3 h-3 ${badge.color === 'primary' ? 'bg-primary' : badge.color === 'green' ? 'bg-green-500 animate-pulse' : 'bg-blue-500'} rounded-full`} />
                    <span className="text-gray-400 text-sm group-hover:text-white transition-colors">{badge.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1.5 h-3 bg-primary rounded-full animate-scroll-down" />
        </div>
      </div>
    </section>
  );
}
