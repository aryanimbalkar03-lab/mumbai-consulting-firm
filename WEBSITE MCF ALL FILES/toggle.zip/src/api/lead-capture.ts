/**
 * API Route: /api/lead-capture
 * Handles lead capture form submissions
 * - Sends email notification to aryanimbalkar03@gmail.com
 * - Saves to Google Sheets
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import nodemailer from 'nodemailer';
import { google } from 'googleapis';

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER, // aryanimbalkar03@gmail.com
    pass: process.env.GMAIL_APP_PASSWORD, // Gmail App Password
  },
});

// Google Sheets configuration
const auth = new google.auth.GoogleAuth({
  credentials: JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY || '{}'),
  scopes: ['https://www.googleapis.com/auth/spreadsheets'],
});

const SPREADSHEET_ID = process.env.GOOGLE_SPREADSHEET_ID;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { name, email, phone, countryCode, businessName, timestamp, source } = req.body;

    // Validate required fields
    if (!name || !email || !phone || !businessName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // 1. Send email notification
    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FF1493, #C71585); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #fff; padding: 30px; border: 2px solid #FF1493; border-top: none; border-radius: 0 0 10px 10px; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th { background: #FF1493; color: white; padding: 12px; text-align: left; }
            td { padding: 12px; border-bottom: 1px solid #ddd; }
            .highlight { background: #fff0f8; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">🎯 NEW LEAD CAPTURED!</h1>
              <p style="margin: 10px 0 0 0;">Mumbai Consulting Firm</p>
            </div>
            <div class="content">
              <h2 style="color: #FF1493;">Lead Information</h2>
              <table>
                <tr class="highlight">
                  <th>Field</th>
                  <th>Value</th>
                </tr>
                <tr>
                  <td><strong>Name</strong></td>
                  <td>${name}</td>
                </tr>
                <tr class="highlight">
                  <td><strong>Email</strong></td>
                  <td><a href="mailto:${email}">${email}</a></td>
                </tr>
                <tr>
                  <td><strong>Phone</strong></td>
                  <td><a href="tel:${countryCode}${phone}">${countryCode} ${phone}</a></td>
                </tr>
                <tr class="highlight">
                  <td><strong>Business Name</strong></td>
                  <td>${businessName}</td>
                </tr>
                <tr>
                  <td><strong>Source</strong></td>
                  <td>${source || 'Website'}</td>
                </tr>
                <tr class="highlight">
                  <td><strong>Timestamp</strong></td>
                  <td>${new Date(timestamp).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</td>
                </tr>
              </table>
              
              <div style="background: #fff0f8; border-left: 4px solid #FF1493; padding: 15px; margin: 20px 0;">
                <p style="margin: 0;"><strong>⚡ Quick Actions:</strong></p>
                <ul style="margin: 10px 0;">
                  <li>Reply to: <a href="mailto:${email}">${email}</a></li>
                  <li>Call: <a href="tel:${countryCode}${phone}">${countryCode} ${phone}</a></li>
                  <li>They're waiting for the FREE audit results!</li>
                </ul>
              </div>
            </div>
            <div class="footer">
              <p>This is an automated notification from your website lead capture system.</p>
              <p>Mumbai Consulting Firm • aryanimbalkar03@gmail.com</p>
            </div>
          </div>
        </body>
      </html>
    `;

    await transporter.sendMail({
      from: `"MCF Lead System" <${process.env.GMAIL_USER}>`,
      to: 'aryanimbalkar03@gmail.com',
      subject: `🎯 NEW LEAD: ${name} - ${businessName}`,
      html: emailHtml,
    });

    // 2. Save to Google Sheets
    const sheets = google.sheets({ version: 'v4', auth });
    
    const values = [
      [
        new Date(timestamp).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
        name,
        email,
        `${countryCode} ${phone}`,
        businessName,
        source || 'Website',
        'Lead Captured',
      ],
    ];

    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Leads!A:G', // Sheet name: "Leads", Columns A-G
      valueInputOption: 'RAW',
      requestBody: { values },
    });

    return res.status(200).json({ 
      success: true,
      message: 'Lead captured successfully',
    });

  } catch (error) {
    console.error('Error processing lead:', error);
    return res.status(500).json({ 
      error: 'Failed to process lead',
      details: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}
