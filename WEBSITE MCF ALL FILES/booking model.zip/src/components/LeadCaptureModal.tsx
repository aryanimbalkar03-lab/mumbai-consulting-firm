import { X, User, Mail, Phone, Building2, CheckCircle } from 'lucide-react';
import { useState } from 'react';

interface LeadCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: LeadData) => void;
}

export interface LeadData {
  name: string;
  email: string;
  phone: string;
  countryCode: string;
  businessName: string;
}

export function LeadCaptureModal({ isOpen, onClose, onSubmit }: LeadCaptureModalProps) {
  const [formData, setFormData] = useState<LeadData>({
    name: '',
    email: '',
    phone: '',
    countryCode: '+91',
    businessName: '',
  });
  
  const [errors, setErrors] = useState<Partial<Record<keyof LeadData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    // Remove spaces, dashes, parentheses
    const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
    // Check if it's a valid phone number (digits only, 7-15 chars)
    const phoneRegex = /^\d{7,15}$/;
    return phoneRegex.test(cleanPhone);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Partial<Record<keyof LeadData, string>> = {};

    // Validate name
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Name must be at least 2 characters';
    }

    // Validate email
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Validate phone
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number (digits only, 7-15 characters)';
    }

    // Validate business name
    if (!formData.businessName.trim()) {
      newErrors.businessName = 'Business name is required';
    }

    setErrors(newErrors);

    // If there are errors, don't submit
    if (Object.keys(newErrors).length > 0) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Call the onSubmit callback with the form data
      await onSubmit(formData);
      
      // Reset form after successful submission
      setFormData({
        name: '',
        email: '',
        phone: '',
        countryCode: '+91',
        businessName: '',
      });
      setErrors({});
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('There was an error submitting your information. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: keyof LeadData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fadeIn">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-primary/30 rounded-full animate-particle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative group max-w-2xl w-full animate-scale-in">
        {/* Glow effect */}
        <div className="absolute -inset-4 bg-gradient-to-r from-primary via-pink-500 to-primary rounded-3xl blur-2xl opacity-50 group-hover:opacity-75 transition-opacity animate-pulse-slow" />
        
        {/* Main Modal */}
        <div className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 border-4 border-primary rounded-3xl p-8 md:p-12 shadow-2xl">
          
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-gray-400 hover:text-primary hover:rotate-90 transition-all duration-300 hover:scale-110"
            aria-label="Close"
          >
            <X size={32} />
          </button>

          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-block px-6 py-3 bg-primary/20 border-2 border-primary rounded-full mb-6 animate-pulse-glow">
              <span className="text-primary tracking-wide">🎯 UNLOCK YOUR FREE BUSINESS AUDIT</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 animate-slideInUp">
              Almost There!
            </h2>
            
            <p className="text-gray-300 text-lg animate-slideInUp" style={{ animationDelay: '0.1s' }}>
              Enter your details to access the 11-point AI diagnostic that's helped businesses uncover{' '}
              <span className="text-primary font-semibold">40-80% hidden profit potential</span>.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Name */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.2s' }}>
              <label className="block text-white mb-2 flex items-center gap-2">
                <User size={20} className="text-primary" />
                <span>Full Name *</span>
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                className={`w-full px-4 py-4 bg-white/10 border-2 ${
                  errors.name ? 'border-red-500 animate-shake' : 'border-white/20'
                } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 text-lg transition-all`}
                placeholder="John Doe"
              />
              {errors.name && <p className="text-red-400 text-sm mt-1 animate-slideInUp">{errors.name}</p>}
            </div>

            {/* Email */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.3s' }}>
              <label className="block text-white mb-2 flex items-center gap-2">
                <Mail size={20} className="text-primary" />
                <span>Email Address *</span>
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                className={`w-full px-4 py-4 bg-white/10 border-2 ${
                  errors.email ? 'border-red-500 animate-shake' : 'border-white/20'
                } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 text-lg transition-all`}
                placeholder="john@company.com"
              />
              {errors.email && <p className="text-red-400 text-sm mt-1 animate-slideInUp">{errors.email}</p>}
            </div>

            {/* Phone with Country Code */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.4s' }}>
              <label className="block text-white mb-2 flex items-center gap-2">
                <Phone size={20} className="text-primary" />
                <span>Phone Number *</span>
              </label>
              <div className="flex gap-3">
                <select
                  value={formData.countryCode}
                  onChange={(e) => handleChange('countryCode', e.target.value)}
                  className="px-4 py-4 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white text-lg transition-all cursor-pointer hover:bg-white/20"
                >
                  <option value="+91" className="bg-gray-900">🇮🇳 +91</option>
                  <option value="+1" className="bg-gray-900">🇺🇸 +1</option>
                  <option value="+44" className="bg-gray-900">🇬🇧 +44</option>
                  <option value="+971" className="bg-gray-900">🇦🇪 +971</option>
                  <option value="+65" className="bg-gray-900">🇸🇬 +65</option>
                  <option value="+61" className="bg-gray-900">🇦🇺 +61</option>
                  <option value="+86" className="bg-gray-900">🇨🇳 +86</option>
                  <option value="+81" className="bg-gray-900">🇯🇵 +81</option>
                  <option value="+49" className="bg-gray-900">🇩🇪 +49</option>
                  <option value="+33" className="bg-gray-900">🇫🇷 +33</option>
                </select>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  className={`flex-1 px-4 py-4 bg-white/10 border-2 ${
                    errors.phone ? 'border-red-500 animate-shake' : 'border-white/20'
                  } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 text-lg transition-all`}
                  placeholder="9833411578"
                />
              </div>
              {errors.phone && <p className="text-red-400 text-sm mt-1 animate-slideInUp">{errors.phone}</p>}
              <p className="text-gray-500 text-xs mt-1">Enter digits only (no spaces or dashes)</p>
            </div>

            {/* Business Name */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.5s' }}>
              <label className="block text-white mb-2 flex items-center gap-2">
                <Building2 size={20} className="text-primary" />
                <span>Business Name *</span>
              </label>
              <input
                type="text"
                value={formData.businessName}
                onChange={(e) => handleChange('businessName', e.target.value)}
                className={`w-full px-4 py-4 bg-white/10 border-2 ${
                  errors.businessName ? 'border-red-500 animate-shake' : 'border-white/20'
                } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 text-lg transition-all`}
                placeholder="My Company Pvt Ltd"
              />
              {errors.businessName && <p className="text-red-400 text-sm mt-1 animate-slideInUp">{errors.businessName}</p>}
            </div>

            {/* Trust badges */}
            <div className="bg-primary/10 border-l-4 border-primary p-4 rounded-r-lg animate-slideInUp" style={{ animationDelay: '0.6s' }}>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-primary flex-shrink-0 mt-1 animate-pulse" size={20} />
                <div>
                  <p className="text-white text-sm">
                    <strong className="text-primary">100% Confidential</strong> - Your information is never shared and is used solely to provide you with personalized business insights.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="group relative w-full animate-slideInUp" style={{ animationDelay: '0.7s' }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary via-pink-500 to-primary rounded-xl blur-lg opacity-75 group-hover:opacity-100 transition-opacity" />
              <div className="relative bg-gradient-to-r from-primary to-pink-600 text-white px-8 py-5 rounded-xl hover:shadow-2xl transform hover:scale-105 text-xl md:text-2xl font-black disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300">
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-3">
                    <svg className="animate-spin h-6 w-6" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </span>
                ) : (
                  '🚀 START MY FREE AUDIT NOW'
                )}
              </div>
            </button>

            <p className="text-center text-gray-500 text-sm animate-slideInUp" style={{ animationDelay: '0.8s' }}>
              By continuing, you agree to receive business insights via email. Unsubscribe anytime.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}