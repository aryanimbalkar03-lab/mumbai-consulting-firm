# ⚡ Quick Start Guide - 15 Minutes to Launch

## 🎯 Goal
Get your Mumbai Consulting Firm website live in 15 minutes with full functionality.

---

## ⏱️ Step 1: Deploy to Vercel (3 minutes)

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Launch Mumbai Consulting Firm"
   git push origin main
   ```

2. **Deploy on Vercel:**
   - Go to [vercel.com](https://vercel.com/new)
   - Import your GitHub repo
   - Click "Deploy"
   - ✅ Website is now live!

---

## ⏱️ Step 2: Gmail Setup (4 minutes)

1. **Create App Password:**
   - Go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
   - (Enable 2FA first if needed)
   - Select "Mail" + "Other"
   - Copy the 16-char password

2. **Add to Vercel:**
   - Vercel → Your Project → Settings → Environment Variables
   - Add:
     ```
     GMAIL_USER = aryanimbalkar03@gmail.com
     GMAIL_APP_PASSWORD = [paste password]
     ```

---

## ⏱️ Step 3: Google Sheets (5 minutes)

1. **Create Spreadsheet:**
   - [Google Sheets](https://sheets.google.com) → New
   - Name: "MCF Lead Database"
   - Create 2 sheets:
     - **"Leads"**: Timestamp | Name | Email | Phone | Business Name | Source | Status
     - **"Audits"**: Timestamp | Name | Email | Phone | Business | Industry | ... (21 columns total)
   - Copy Spreadsheet ID from URL

2. **Create Service Account:**
   - [console.cloud.google.com](https://console.cloud.google.com)
   - New Project → "Mumbai Consulting"
   - Enable "Google Sheets API"
   - IAM & Admin → Service Accounts → Create
   - Name: "sheets-access" → Create → Role: Editor
   - Create JSON Key → Download

3. **Share Sheet:**
   - Open your spreadsheet
   - Share with service account email (ends with @iam.gserviceaccount.com)
   - Give "Editor" access

4. **Add to Vercel:**
   - Open downloaded JSON file
   - Copy entire contents
   - Vercel → Environment Variables → Add:
     ```
     GOOGLE_SERVICE_ACCOUNT_KEY = [paste JSON]
     GOOGLE_SPREADSHEET_ID = [paste ID]
     ```

---

## ⏱️ Step 4: Redeploy (1 minute)

- Vercel → Deployments → Click "Redeploy"
- Wait 30 seconds
- ✅ Everything is live!

---

## ⏱️ Step 5: Test (2 minutes)

1. **Test Lead Capture:**
   - Visit your site
   - Click "Get FREE Audit Now"
   - Fill form → Submit
   - ✅ Check email
   - ✅ Check "Leads" sheet

2. **Test Audit:**
   - Complete full audit
   - ✅ Check email
   - ✅ Check "Audits" sheet

---

## 🎉 Done!

Your website is fully functional with:
- ✅ Lead capture
- ✅ Email notifications
- ✅ Google Sheets database
- ✅ AI diagnostics

**Live URL:** https://your-project.vercel.app

---

## 🆘 Quick Fixes

**Email not working?**
- Check Gmail App Password (no spaces)
- Check spam folder

**Sheets not updating?**
- Verify sheet is shared
- Check sheet names exactly match "Leads" and "Audits"

**Form won't submit?**
- Check browser console
- Verify all fields are filled

---

## 📞 Need Help?

Email: aryanimbalkar03@gmail.com
Phone: +91 9833411578

---

## 📚 Full Documentation

For detailed setup: See `DEPLOYMENT_GUIDE.md`

For features: See `README_DEPLOYMENT.md`

---

## 🔥 Pro Tips

1. **Test immediately** after deployment
2. **Bookmark** your Google Sheet for quick access
3. **Set up email filters** in Gmail for MCF notifications
4. **Monitor** the Google Sheet daily for new leads
5. **Respond fast** to inquiries for best conversion

---

Made with ❤️ for Mumbai Consulting Firm

**Your business, automated. Your growth, accelerated.**
