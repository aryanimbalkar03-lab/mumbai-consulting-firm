import { X, User, Mail, Phone, Calendar, Clock, MessageSquare, CheckCircle, Building2 } from 'lucide-react';
import { useState } from 'react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface BookingData {
  name: string;
  email: string;
  phone: string;
  countryCode: string;
  businessName: string;
  preferredDate: string;
  preferredTime: string;
  message: string;
}

export function BookingModal({ isOpen, onClose }: BookingModalProps) {
  const [formData, setFormData] = useState<BookingData>({
    name: '',
    email: '',
    phone: '',
    countryCode: '+91',
    businessName: '',
    preferredDate: '',
    preferredTime: '',
    message: '',
  });
  
  const [errors, setErrors] = useState<Partial<Record<keyof BookingData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
    const phoneRegex = /^\d{7,15}$/;
    return phoneRegex.test(cleanPhone);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const newErrors: Partial<Record<keyof BookingData, string>> = {};

    if (!formData.name.trim() || formData.name.trim().length < 2) {
      newErrors.name = 'Please enter your full name';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number';
    }

    if (!formData.businessName.trim()) {
      newErrors.businessName = 'Business name is required';
    }

    if (!formData.preferredDate) {
      newErrors.preferredDate = 'Please select a preferred date';
    }

    if (!formData.preferredTime) {
      newErrors.preferredTime = 'Please select a preferred time';
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Send booking data to backend
      await fetch('/api/lead-capture', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          timestamp: new Date().toISOString(),
          source: 'Consultation Booking',
        }),
      });

      setIsSuccess(true);
      
      // Close after 3 seconds
      setTimeout(() => {
        onClose();
        setIsSuccess(false);
        setFormData({
          name: '',
          email: '',
          phone: '',
          countryCode: '+91',
          businessName: '',
          preferredDate: '',
          preferredTime: '',
          message: '',
        });
      }, 3000);
    } catch (error) {
      console.error('Error submitting booking:', error);
      alert('There was an error submitting your booking. Please try again or contact us directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: keyof BookingData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  // Get today's date in YYYY-MM-DD format for min date
  const today = new Date().toISOString().split('T')[0];

  // Success state
  if (isSuccess) {
    return (
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fadeIn">
        <div className="bg-gradient-to-br from-gray-900 via-black to-gray-900 border-4 border-primary rounded-3xl max-w-md w-full p-12 text-center animate-scale-in">
          <div className="mb-6">
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-scale-pulse">
              <CheckCircle className="w-12 h-12 text-green-500" />
            </div>
            <h2 className="text-3xl font-black text-white mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              BOOKING CONFIRMED!
            </h2>
            <p className="text-gray-300 text-lg">
              We'll contact you within <span className="text-primary font-bold">24 hours</span> to confirm your consultation session.
            </p>
          </div>
          <div className="text-sm text-gray-500">
            Check your email at <span className="text-primary">{formData.email}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fadeIn overflow-y-auto">
      <div className="relative group max-w-3xl w-full my-8 animate-scale-in">
        {/* Glow effect */}
        <div className="absolute -inset-4 bg-gradient-to-r from-primary via-pink-500 to-primary rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-opacity" />
        
        {/* Main Modal */}
        <div className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 border-4 border-primary rounded-3xl p-8 md:p-12 shadow-2xl">
          
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-gray-400 hover:text-primary hover:rotate-90 transition-all duration-300 hover:scale-110"
            aria-label="Close"
          >
            <X size={32} />
          </button>

          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-primary/20 border-2 border-primary rounded-full mb-6">
              <Calendar className="w-5 h-5 text-primary" />
              <span className="text-primary tracking-wide font-bold" style={{ fontFamily: 'var(--font-heading)' }}>BOOK YOUR FREE AUDIT SESSION</span>
            </div>
            
            <h2 className="text-3xl md:text-4xl font-black text-white mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
              SCHEDULE YOUR CONSULTATION
            </h2>
            
            <p className="text-gray-300 text-lg">
              Book a <span className="text-primary font-bold">free 30-minute session</span> with our consulting experts. We'll discuss your business challenges and outline a clear action plan.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* Two Column Layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Name */}
              <div className="animate-slideInUp" style={{ animationDelay: '0.1s' }}>
                <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                  <User size={18} className="text-primary" />
                  <span style={{ fontFamily: 'var(--font-heading)' }}>Full Name *</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  className={`w-full px-4 py-3 bg-white/10 border-2 ${
                    errors.name ? 'border-red-500 animate-shake' : 'border-white/20'
                  } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 transition-all`}
                  placeholder="John Doe"
                  style={{ fontFamily: 'var(--font-heading)' }}
                />
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
              </div>

              {/* Email */}
              <div className="animate-slideInUp" style={{ animationDelay: '0.15s' }}>
                <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                  <Mail size={18} className="text-primary" />
                  <span style={{ fontFamily: 'var(--font-heading)' }}>Email Address *</span>
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  className={`w-full px-4 py-3 bg-white/10 border-2 ${
                    errors.email ? 'border-red-500 animate-shake' : 'border-white/20'
                  } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 transition-all`}
                  placeholder="john@company.com"
                  style={{ fontFamily: 'var(--font-heading)' }}
                />
                {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
              </div>
            </div>

            {/* Phone */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.2s' }}>
              <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                <Phone size={18} className="text-primary" />
                <span style={{ fontFamily: 'var(--font-heading)' }}>Phone Number *</span>
              </label>
              <div className="flex gap-3">
                <select
                  value={formData.countryCode}
                  onChange={(e) => handleChange('countryCode', e.target.value)}
                  className="px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white transition-all cursor-pointer hover:bg-white/20"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  <option value="+91" className="bg-gray-900">🇮🇳 +91</option>
                  <option value="+1" className="bg-gray-900">🇺🇸 +1</option>
                  <option value="+44" className="bg-gray-900">🇬🇧 +44</option>
                  <option value="+971" className="bg-gray-900">🇦🇪 +971</option>
                  <option value="+65" className="bg-gray-900">🇸🇬 +65</option>
                </select>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  className={`flex-1 px-4 py-3 bg-white/10 border-2 ${
                    errors.phone ? 'border-red-500 animate-shake' : 'border-white/20'
                  } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 transition-all`}
                  placeholder="9833411578"
                  style={{ fontFamily: 'var(--font-heading)' }}
                />
              </div>
              {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
            </div>

            {/* Business Name */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.25s' }}>
              <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                <Building2 size={18} className="text-primary" />
                <span style={{ fontFamily: 'var(--font-heading)' }}>Business Name *</span>
              </label>
              <input
                type="text"
                value={formData.businessName}
                onChange={(e) => handleChange('businessName', e.target.value)}
                className={`w-full px-4 py-3 bg-white/10 border-2 ${
                  errors.businessName ? 'border-red-500 animate-shake' : 'border-white/20'
                } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 transition-all`}
                placeholder="My Company Pvt Ltd"
                style={{ fontFamily: 'var(--font-heading)' }}
              />
              {errors.businessName && <p className="text-red-400 text-xs mt-1">{errors.businessName}</p>}
            </div>

            {/* Date and Time */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Preferred Date */}
              <div className="animate-slideInUp" style={{ animationDelay: '0.3s' }}>
                <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                  <Calendar size={18} className="text-primary" />
                  <span style={{ fontFamily: 'var(--font-heading)' }}>Preferred Date *</span>
                </label>
                <input
                  type="date"
                  value={formData.preferredDate}
                  onChange={(e) => handleChange('preferredDate', e.target.value)}
                  min={today}
                  className={`w-full px-4 py-3 bg-white/10 border-2 ${
                    errors.preferredDate ? 'border-red-500 animate-shake' : 'border-white/20'
                  } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white transition-all cursor-pointer`}
                  style={{ fontFamily: 'var(--font-heading)' }}
                />
                {errors.preferredDate && <p className="text-red-400 text-xs mt-1">{errors.preferredDate}</p>}
              </div>

              {/* Preferred Time */}
              <div className="animate-slideInUp" style={{ animationDelay: '0.35s' }}>
                <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                  <Clock size={18} className="text-primary" />
                  <span style={{ fontFamily: 'var(--font-heading)' }}>Preferred Time *</span>
                </label>
                <select
                  value={formData.preferredTime}
                  onChange={(e) => handleChange('preferredTime', e.target.value)}
                  className={`w-full px-4 py-3 bg-white/10 border-2 ${
                    errors.preferredTime ? 'border-red-500 animate-shake' : 'border-white/20'
                  } rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white transition-all cursor-pointer`}
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  <option value="" className="bg-gray-900">Select time</option>
                  <option value="09:00-10:00" className="bg-gray-900">09:00 - 10:00 AM</option>
                  <option value="10:00-11:00" className="bg-gray-900">10:00 - 11:00 AM</option>
                  <option value="11:00-12:00" className="bg-gray-900">11:00 AM - 12:00 PM</option>
                  <option value="12:00-13:00" className="bg-gray-900">12:00 - 01:00 PM</option>
                  <option value="14:00-15:00" className="bg-gray-900">02:00 - 03:00 PM</option>
                  <option value="15:00-16:00" className="bg-gray-900">03:00 - 04:00 PM</option>
                  <option value="16:00-17:00" className="bg-gray-900">04:00 - 05:00 PM</option>
                  <option value="17:00-18:00" className="bg-gray-900">05:00 - 06:00 PM</option>
                </select>
                {errors.preferredTime && <p className="text-red-400 text-xs mt-1">{errors.preferredTime}</p>}
              </div>
            </div>

            {/* Message (Optional) */}
            <div className="animate-slideInUp" style={{ animationDelay: '0.4s' }}>
              <label className="block text-white mb-2 flex items-center gap-2 text-sm">
                <MessageSquare size={18} className="text-primary" />
                <span style={{ fontFamily: 'var(--font-heading)' }}>Additional Notes (Optional)</span>
              </label>
              <textarea
                value={formData.message}
                onChange={(e) => handleChange('message', e.target.value)}
                rows={3}
                className="w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 text-white placeholder-gray-500 transition-all resize-none"
                placeholder="Tell us briefly about your business challenges..."
                style={{ fontFamily: 'var(--font-heading)' }}
              />
            </div>

            {/* Info Box */}
            <div className="bg-primary/10 border-l-4 border-primary p-4 rounded-r-lg animate-slideInUp" style={{ animationDelay: '0.45s' }}>
              <div className="flex items-start gap-3">
                <CheckCircle className="text-primary flex-shrink-0 mt-1" size={20} />
                <div>
                  <p className="text-white text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
                    <strong className="text-primary">What to Expect:</strong> Our expert will call you to confirm your session and discuss your business needs. Come prepared with your business metrics for maximum value.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="group relative w-full animate-slideInUp" style={{ animationDelay: '0.5s' }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary via-pink-500 to-primary rounded-xl blur-lg opacity-75 group-hover:opacity-100 transition-opacity" />
              <div className="relative bg-gradient-to-r from-primary to-pink-600 text-white px-8 py-4 rounded-xl hover:shadow-2xl transform hover:scale-105 font-black disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300" style={{ fontFamily: 'var(--font-heading)' }}>
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-3">
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    BOOKING...
                  </span>
                ) : (
                  '🗓️ CONFIRM BOOKING'
                )}
              </div>
            </button>

            <p className="text-center text-gray-500 text-xs animate-slideInUp" style={{ animationDelay: '0.55s' }}>
              By booking, you agree to receive communication about your consultation. We respect your privacy.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
