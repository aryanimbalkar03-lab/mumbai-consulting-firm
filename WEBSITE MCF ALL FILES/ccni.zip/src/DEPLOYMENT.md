# Deployment Guide - Mumbai Consulting Firm Website

## 🚀 Quick Deploy (Recommended)

### Option 1: Vercel (Fastest)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit - MCF website"
   git remote add origin YOUR_GITHUB_REPO_URL
   git push -u origin main
   ```

2. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Vercel will auto-detect React
   - Click "Deploy"
   - Your site will be live in ~2 minutes!

3. **Custom Domain** (Optional)
   - In Vercel dashboard, go to Settings > Domains
   - Add your custom domain (e.g., mumbaic consulting.com)
   - Follow DNS instructions

### Option 2: Netlify

1. **Push to GitHub** (same as above)

2. **Deploy to Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Click "Add new site" > "Import an existing project"
   - Connect to GitHub
   - Select your repository
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Click "Deploy"

### Option 3: GitHub Pages

1. **Install gh-pages**
   ```bash
   npm install --save-dev gh-pages
   ```

2. **Update package.json**
   ```json
   {
     "homepage": "https://yourusername.github.io/mcf-website",
     "scripts": {
       "predeploy": "npm run build",
       "deploy": "gh-pages -d dist"
     }
   }
   ```

3. **Deploy**
   ```bash
   npm run deploy
   ```

## 📦 Build for Production

```bash
# Install dependencies
npm install

# Build optimized production bundle
npm run build

# Preview production build locally
npm run preview
```

## 🔧 Environment Setup

Create `.env` file (don't commit this!):

```env
VITE_GOOGLE_SHEETS_URL=your_apps_script_url_here
VITE_CONTACT_EMAIL=aryanimbalkar03@gmail.com
```

## 📊 Analytics Setup

### Google Analytics
Add to `/index.html` before `</head>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

## 🔒 Security Checklist

- [ ] Remove console.log statements in production
- [ ] Set up CSP headers
- [ ] Enable HTTPS only
- [ ] Add rate limiting to forms
- [ ] Set up proper CORS policies
- [ ] Validate all form inputs
- [ ] Don't expose API keys in frontend

## 🎯 Performance Optimization

Your site is already optimized with:
- ✅ Code splitting
- ✅ Lazy loading
- ✅ Optimized images
- ✅ Minified CSS/JS
- ✅ Tree-shaking

### Additional Optimizations

1. **Enable Compression** (handled by Vercel/Netlify automatically)

2. **Add CDN** (handled by Vercel/Netlify automatically)

3. **Optimize Images Further**
   ```bash
   npm install -D vite-imagetools
   ```

## 📱 Testing Checklist

- [ ] Test on mobile devices (iOS & Android)
- [ ] Test on different browsers (Chrome, Safari, Firefox, Edge)
- [ ] Test form submissions
- [ ] Test email notifications
- [ ] Test Google Sheets integration
- [ ] Check page load speed (use Google PageSpeed Insights)
- [ ] Test all navigation links
- [ ] Test responsiveness at different screen sizes

## 🌐 SEO Setup

Add to `/index.html`:

```html
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <!-- Primary Meta Tags -->
  <title>Mumbai Consulting Firm - AI-Powered Business Consulting</title>
  <meta name="title" content="Mumbai Consulting Firm - AI-Powered Business Consulting">
  <meta name="description" content="Get a FREE detailed business audit. AI-powered consulting for young businesses in Mumbai. We only win when you win.">
  <meta name="keywords" content="business consulting, Mumbai, AI consulting, business audit, strategy consulting">
  
  <!-- Open Graph / Facebook -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://yourdomain.com/">
  <meta property="og:title" content="Mumbai Consulting Firm - AI-Powered Business Consulting">
  <meta property="og:description" content="Get a FREE detailed business audit. AI-powered consulting for young businesses in Mumbai.">
  <meta property="og:image" content="https://yourdomain.com/og-image.jpg">
  
  <!-- Twitter -->
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:url" content="https://yourdomain.com/">
  <meta property="twitter:title" content="Mumbai Consulting Firm - AI-Powered Business Consulting">
  <meta property="twitter:description" content="Get a FREE detailed business audit. AI-powered consulting for young businesses in Mumbai.">
  <meta property="twitter:image" content="https://yourdomain.com/og-image.jpg">
  
  <!-- Favicon -->
  <link rel="icon" type="image/png" href="/favicon.png" />
</head>
```

## 📧 Email Setup (Post-Deployment)

1. **Set up Google Apps Script** (see BACKEND_INTEGRATION.md)
2. **Test email deliverability**
3. **Set up email forwarding** if needed
4. **Monitor spam folder** for test emails

## 🔔 Monitoring

### Set Up Alerts

1. **Vercel/Netlify Dashboard**
   - Monitor deployment status
   - Track visitor analytics

2. **Google Analytics**
   - Track form submissions
   - Monitor bounce rates
   - Track conversion rates

3. **Email Alerts**
   - Set up Gmail filters for audit submissions
   - Create labels for priority contacts

## 🆘 Troubleshooting

### Build Fails
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Forms Not Submitting
- Check browser console for errors
- Verify Google Apps Script URL
- Test Apps Script endpoint directly
- Check CORS settings

### Styles Not Loading
- Clear browser cache
- Check if globals.css is imported
- Verify Tailwind configuration

## 📞 Support Contacts

- **Website Issues**: Check browser console first
- **Email Issues**: Check Google Apps Script logs
- **Domain Issues**: Contact your domain provider

## 🎉 Launch Checklist

Final checklist before going live:

- [ ] Test all forms (Audit + Contact)
- [ ] Verify email notifications work
- [ ] Check Google Sheets integration
- [ ] Test on mobile devices
- [ ] Test on different browsers
- [ ] Set up Google Analytics
- [ ] Add custom domain
- [ ] Set up SSL certificate (auto with Vercel/Netlify)
- [ ] Test page speed
- [ ] Share with test users
- [ ] Announce launch! 🚀

## 📈 Post-Launch

Week 1:
- Monitor form submissions daily
- Check email deliverability
- Review analytics
- Gather user feedback

Month 1:
- Analyze conversion rates
- Optimize based on user behavior
- A/B test call-to-action buttons
- Improve load times if needed

## 🔄 Updates

To deploy updates:

```bash
# Make changes
git add .
git commit -m "Description of changes"
git push origin main

# Vercel/Netlify will auto-deploy
# Or run: npm run deploy (for GitHub Pages)
```

---

**Your website is now ready to deploy! 🎊**

Choose Vercel or Netlify for the easiest deployment experience.
