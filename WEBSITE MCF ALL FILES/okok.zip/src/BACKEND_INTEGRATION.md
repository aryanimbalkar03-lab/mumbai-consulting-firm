# Backend Integration Guide for Mumbai Consulting Firm

## Overview
This document explains how to integrate email notifications and Google Sheets data collection for the MCF website.

## Current Status
✅ **Frontend Complete**: All forms capture and validate data
✅ **Data Structure Ready**: Forms collect name, email, phone, and audit results
⚠️ **Backend Needed**: Email sending and Google Sheets integration require server-side code

## Option 1: Google Sheets + Apps Script (Recommended for Quick Setup)

### Step 1: Create Google Sheet
1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new sheet named "MCF Audit Submissions"
3. Add these column headers in Row 1:
   - A1: `Timestamp`
   - B1: `Name`
   - C1: `Email`
   - D1: `Phone`
   - E1: `Country Code`
   - F1: `Industry`
   - G1: `Health Score`
   - H1: `Red Flags Count`
   - I1: `Consulting Needed`
   - J1: `Summary`

### Step 2: Create Apps Script
1. In your Google Sheet, click `Extensions` > `Apps Script`
2. Delete existing code and paste this:

```javascript
function doPost(e) {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    const data = JSON.parse(e.postData.contents);
    
    // Add row to sheet
    sheet.appendRow([
      new Date(),
      data.name,
      data.email,
      data.phone,
      data.countryCode,
      data.industry,
      data.healthScore,
      data.redFlagsCount,
      data.consultingNeeded ? 'YES' : 'NO',
      data.summary
    ]);
    
    // Send email notification
    const emailBody = `
NEW BUSINESS AUDIT SUBMISSION

Client Information:
-------------------
Name: ${data.name}
Email: ${data.email}
Phone: ${data.countryCode} ${data.phone}
Industry: ${data.industry}

Audit Results:
--------------
Health Score: ${data.healthScore}/100
Red Flags: ${data.redFlagsCount}
Consulting Needed: ${data.consultingNeeded ? 'YES' : 'NO'}

Summary:
--------
${data.summary}

Timestamp: ${new Date().toLocaleString('en-IN')}
    `;
    
    MailApp.sendEmail({
      to: 'aryanimbalkar03@gmail.com',
      subject: `New Audit: ${data.name} - Score: ${data.healthScore}/100`,
      body: emailBody
    });
    
    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      message: 'Data saved successfully'
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService.createTextOutput('MCF Backend API Running');
}
```

3. Click `Deploy` > `New deployment`
4. Select type: `Web app`
5. Execute as: `Me`
6. Who has access: `Anyone`
7. Click `Deploy`
8. Copy the Web App URL

### Step 3: Update Frontend Code

In `/components/Assessment.tsx`, find the section after `setResult({...})` and replace the console.log with this:

```typescript
// Send to Google Sheets
if (leadData) {
  const submissionData = {
    name: leadData.name,
    email: leadData.email,
    phone: leadData.phone,
    countryCode: leadData.countryCode,
    industry,
    healthScore,
    redFlagsCount: redFlags.length,
    consultingNeeded,
    summary: summary.join(' | ')
  };
  
  fetch('YOUR_GOOGLE_APPS_SCRIPT_URL_HERE', {
    method: 'POST',
    mode: 'no-cors',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(submissionData)
  }).catch(err => console.error('Error sending data:', err));
}
```

## Option 2: Firebase Functions (Scalable Solution)

### Setup
```bash
npm install firebase firebase-functions
```

### Create Function
```javascript
const functions = require('firebase-functions');
const nodemailer = require('nodemailer');
const { google } = require('googleapis');

exports.submitAudit = functions.https.onCall(async (data, context) => {
  // Add to Google Sheets
  const auth = new google.auth.GoogleAuth({
    keyFile: 'credentials.json',
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
  
  const sheets = google.sheets({ version: 'v4', auth });
  
  await sheets.spreadsheets.values.append({
    spreadsheetId: 'YOUR_SHEET_ID',
    range: 'Sheet1!A:J',
    valueInputOption: 'RAW',
    resource: {
      values: [[
        new Date().toISOString(),
        data.name,
        data.email,
        data.phone,
        data.countryCode,
        data.industry,
        data.healthScore,
        data.redFlagsCount,
        data.consultingNeeded,
        data.summary
      ]]
    }
  });
  
  // Send email
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'aryanimbalkar03@gmail.com',
      pass: 'YOUR_APP_PASSWORD' // Generate from Google Account Settings
    }
  });
  
  await transporter.sendMail({
    from: '"MCF Audit System" <aryanimbalkar03@gmail.com>',
    to: 'aryanimbalkar03@gmail.com',
    subject: `New Audit: ${data.name} - Score: ${data.healthScore}/100`,
    html: `
      <h2>New Business Audit Submission</h2>
      <h3>Client Information</h3>
      <p><strong>Name:</strong> ${data.name}<br>
      <strong>Email:</strong> ${data.email}<br>
      <strong>Phone:</strong> ${data.countryCode} ${data.phone}<br>
      <strong>Industry:</strong> ${data.industry}</p>
      
      <h3>Audit Results</h3>
      <p><strong>Health Score:</strong> ${data.healthScore}/100<br>
      <strong>Red Flags:</strong> ${data.redFlagsCount}<br>
      <strong>Consulting Needed:</strong> ${data.consultingNeeded ? 'YES' : 'NO'}</p>
      
      <h3>Summary</h3>
      <p>${data.summary}</p>
    `
  });
  
  return { success: true };
});
```

## Option 3: Supabase (Full Backend Solution)

### Setup
```bash
npm install @supabase/supabase-js
```

### Create Table
```sql
CREATE TABLE audit_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP DEFAULT NOW(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  country_code TEXT NOT NULL,
  industry TEXT NOT NULL,
  health_score INTEGER NOT NULL,
  red_flags_count INTEGER NOT NULL,
  consulting_needed BOOLEAN NOT NULL,
  summary TEXT NOT NULL
);
```

### Frontend Integration
```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient('YOUR_URL', 'YOUR_ANON_KEY');

// In Assessment.tsx
const { data, error } = await supabase
  .from('audit_submissions')
  .insert([submissionData]);
```

## Testing

### Test Data Structure
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9833411578",
  "countryCode": "+91",
  "industry": "E-commerce",
  "healthScore": 65,
  "redFlagsCount": 3,
  "consultingNeeded": true,
  "summary": "Business needs consulting NOW"
}
```

### Test the Integration
1. Fill out the audit form
2. Check Google Sheets for new row
3. Check aryanimbalkar03@gmail.com for email
4. Verify all data is captured correctly

## Security Notes

🔒 **Never expose API keys in frontend code**
🔒 **Use environment variables for sensitive data**
🔒 **Validate all inputs server-side**
🔒 **Add rate limiting to prevent spam**
🔒 **Use HTTPS only**

## Contact Form Setup

The Contact form (`/components/Contact.tsx`) works similarly. To connect it:

1. Use the same Google Apps Script endpoint
2. Modify the script to handle contact form data
3. Add a separate sheet tab for contact submissions

## Next Steps

1. ✅ Choose your preferred backend solution (Apps Script recommended for simplicity)
2. ✅ Set up Google Sheet with proper columns
3. ✅ Deploy Google Apps Script and get URL
4. ✅ Update frontend with the Apps Script URL
5. ✅ Test with real submission
6. ✅ Monitor email inbox for notifications

## Support

For issues, contact the development team or refer to:
- [Google Apps Script Documentation](https://developers.google.com/apps-script)
- [Firebase Documentation](https://firebase.google.com/docs)
- [Supabase Documentation](https://supabase.com/docs)
