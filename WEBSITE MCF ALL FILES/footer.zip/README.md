
  # Consulting Website Template

  This is a code bundle for Consulting Website Template. The original project is available at https://www.figma.com/design/4igSnXodVvQboG76kgcFfy/Consulting-Website-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  