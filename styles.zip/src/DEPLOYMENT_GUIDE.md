# 🚀 Deployment Guide - Mumbai Consulting Firm Website

## Overview
This guide will help you deploy your consulting website with full backend integration for:
- ✅ Lead capture form with validation
- ✅ Email notifications to aryanimbalkar03@gmail.com
- ✅ Automatic Google Sheets data storage
- ✅ Professional audit system

---

## Prerequisites

Before deploying, you'll need:
1. **Vercel Account** (free) - for hosting
2. **Gmail App Password** - for sending emails
3. **Google Service Account** - for Google Sheets access

---

## Step 1: Deploy to Vercel

### 1.1 Push Code to GitHub
```bash
git init
git add .
git commit -m "Initial commit - Mumbai Consulting Firm"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mumbai-consulting-firm.git
git push -u origin main
```

### 1.2 Deploy on Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Import your GitHub repository
4. Click "Deploy"

---

## Step 2: Set Up Gmail for Notifications

### 2.1 Enable 2-Factor Authentication
1. Go to [myaccount.google.com/security](https://myaccount.google.com/security)
2. Enable "2-Step Verification"

### 2.2 Create App Password
1. Go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
2. Select "Mail" and "Other (Custom name)"
3. Name it "Mumbai Consulting Website"
4. Click "Generate"
5. **Copy the 16-character password** (you'll need this)

### 2.3 Add to Vercel
1. Go to your Vercel project
2. Settings → Environment Variables
3. Add:
   - `GMAIL_USER` = `aryanimbalkar03@gmail.com`
   - `GMAIL_APP_PASSWORD` = `[your 16-char password]`

---

## Step 3: Set Up Google Sheets

### 3.1 Create a Spreadsheet
1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "MCF Lead Database"
4. Create two sheets:
   - **Sheet 1: "Leads"** with headers:
     ```
     Timestamp | Name | Email | Phone | Business Name | Source | Status
     ```
   - **Sheet 2: "Audits"** with headers:
     ```
     Timestamp | Name | Email | Phone | Business | Industry | Year1 Rev | Year2 Rev | Year3 Rev | Gross Margin | Churn | Repeat Rate | CAC | LTV | Current Ratio | Revenue Growth | Revenue Sources | Health Score | Consulting Needed | Red Flags Count | Red Flags Details
     ```
5. **Copy the Spreadsheet ID** from the URL:
   ```
   https://docs.google.com/spreadsheets/d/[SPREADSHEET_ID]/edit
   ```

### 3.2 Create Service Account
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project: "Mumbai Consulting"
3. Enable **Google Sheets API**:
   - Go to "APIs & Services" → "Library"
   - Search "Google Sheets API"
   - Click "Enable"
4. Create Service Account:
   - Go to "IAM & Admin" → "Service Accounts"
   - Click "Create Service Account"
   - Name: "sheets-access"
   - Click "Create and Continue"
   - Role: "Editor"
   - Click "Done"
5. Create Key:
   - Click on the service account email
   - Go to "Keys" tab
   - "Add Key" → "Create new key"
   - Select "JSON"
   - Download the file

### 3.3 Share Spreadsheet with Service Account
1. Open your spreadsheet
2. Click "Share"
3. Add the service account email (looks like: `sheets-access@mumbai-consulting-xxxxx.iam.gserviceaccount.com`)
4. Give "Editor" access
5. Uncheck "Notify people"
6. Click "Share"

### 3.4 Add to Vercel
1. Open the downloaded JSON file
2. Copy the entire contents
3. Go to Vercel → Settings → Environment Variables
4. Add:
   - `GOOGLE_SERVICE_ACCOUNT_KEY` = `[paste entire JSON]`
   - `GOOGLE_SPREADSHEET_ID` = `[your spreadsheet ID]`

---

## Step 4: Install Dependencies

Add these to your `package.json`:

```json
{
  "dependencies": {
    "nodemailer": "^6.9.7",
    "googleapis": "^128.0.0"
  },
  "devDependencies": {
    "@types/nodemailer": "^6.4.14",
    "@vercel/node": "^3.0.12"
  }
}
```

Then run:
```bash
npm install
```

---

## Step 5: Redeploy

After adding environment variables:
1. Go to Vercel dashboard
2. Click "Deployments"
3. Click "Redeploy" on the latest deployment

---

## Environment Variables Summary

Your Vercel project should have these 4 environment variables:

| Variable | Example Value |
|----------|---------------|
| `GMAIL_USER` | aryanimbalkar03@gmail.com |
| `GMAIL_APP_PASSWORD` | abcd efgh ijkl mnop |
| `GOOGLE_SERVICE_ACCOUNT_KEY` | {"type":"service_account","project_id":"..."} |
| `GOOGLE_SPREADSHEET_ID` | 1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms |

---

## Testing

### Test Lead Capture
1. Visit your deployed site
2. Click "Get FREE Audit Now"
3. Fill in the lead form
4. Check:
   - ✅ Email received at aryanimbalkar03@gmail.com
   - ✅ Data appears in "Leads" sheet

### Test Full Audit
1. Complete the lead form
2. Fill out the entire audit
3. Submit
4. Check:
   - ✅ Email with full audit details
   - ✅ Data appears in "Audits" sheet

---

## Troubleshooting

### Email Not Received
- Verify `GMAIL_APP_PASSWORD` is correct (16 characters, no spaces)
- Check Gmail spam folder
- Ensure 2FA is enabled on Google account

### Google Sheets Error
- Verify spreadsheet is shared with service account email
- Check `GOOGLE_SPREADSHEET_ID` matches your sheet URL
- Ensure Google Sheets API is enabled in Google Cloud Console

### Build Errors
- Run `npm install` to ensure all dependencies are installed
- Check Vercel logs for specific error messages

---

## Security Notes

🔒 **NEVER commit these to GitHub:**
- Gmail App Password
- Google Service Account JSON
- Any API keys

✅ **Always use Vercel Environment Variables** for sensitive data

---

## Support

If you encounter issues:
1. Check Vercel deployment logs
2. Verify all environment variables are set
3. Test with simple data first
4. Check Google Sheets permissions

---

## Success Checklist

- [ ] Website deployed on Vercel
- [ ] Gmail app password created and added
- [ ] Google Sheets created with correct headers
- [ ] Service account created and shared
- [ ] All 4 environment variables added
- [ ] Lead capture tested successfully
- [ ] Audit submission tested successfully
- [ ] Email notifications working
- [ ] Google Sheets auto-updating

---

## 🎉 You're All Set!

Your Mumbai Consulting Firm website is now fully deployed with:
- Professional lead capture
- Automated email notifications
- Real-time Google Sheets database
- AI-powered business diagnostic tool

**Live Site:** https://your-site.vercel.app

**Admin Email:** aryanimbalkar03@gmail.com

**Data Dashboard:** [Your Google Sheet Link]
