export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const dimensions = {
    sm: { container: 'w-10 h-10', svg: 40 },
    md: { container: 'w-12 h-12', svg: 48 },
    lg: { container: 'w-16 h-16', svg: 64 }
  };

  const current = dimensions[size];

  return (
    <div className={`${current.container} relative`}>
      <svg
        width={current.svg}
        height={current.svg}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-lg"
      >
        {/* Background Circle */}
        <circle cx="50" cy="50" r="48" fill="#FFFFFF" />
        <circle cx="50" cy="50" r="44" fill="#FF1493" />
        
        {/* Letter M with Arrow Up (Growth Symbol) */}
        <path
          d="M 30 65 L 30 35 L 42 50 L 50 40 L 58 50 L 70 35 L 70 65"
          stroke="#FFFFFF"
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        
        {/* Small Rising Arrow */}
        <path
          d="M 72 32 L 78 26 L 84 32 M 78 26 L 78 38"
          stroke="#FFFFFF"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        
        {/* Accent Dots for Modern Look */}
        <circle cx="22" cy="50" r="2.5" fill="#FFFFFF" />
        <circle cx="78" cy="50" r="2.5" fill="#FFFFFF" />
      </svg>
    </div>
  );
}