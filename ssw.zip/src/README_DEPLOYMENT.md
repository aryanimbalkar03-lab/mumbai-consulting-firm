# Mumbai Consulting Firm - Professional Website

## 🎯 Overview

A fully-featured consulting website with:
- ✨ **Modern Design**: Pink, black, and white theme with professional animations
- 🤖 **AI-Powered Diagnostics**: 11-point business health assessment
- 📧 **Email Integration**: Automatic notifications with formatted tables
- 📊 **Google Sheets**: Real-time database updates
- 🔒 **Form Validation**: Phone & email verification, country code support
- 📱 **Responsive**: Works perfectly on all devices

---

## 🚀 Features

### Lead Capture System
- Professional modal with validation
- Real phone number verification (7-15 digits)
- Email format validation
- International phone support (+91, +1, +44, etc.)
- Prevents submission without valid data
- Beautiful animated UI

### Business Audit System
- 13-point diagnostic (11 main + 2 advanced)
- Industry-specific benchmarks (E-commerce, SaaS, Salon, etc.)
- Auto-calculated metrics:
  - Gross Margin
  - CAC/LTV Ratio
  - Current Ratio (liquidity)
  - Revenue Growth Rate
  - Data Quality Score
- Red flag detection with severity levels
- Visual charts and radar diagrams
- Professional results dashboard

### Email Notifications
- Formatted HTML emails with tables
- Color-coded red flags
- Quick action buttons
- Professional branding
- Separate emails for:
  1. Lead capture
  2. Complete audit results

### Google Sheets Database
- Two sheets: "Leads" and "Audits"
- Automatic timestamp (IST timezone)
- All customer data organized
- Complete audit metrics
- Red flags summary
- Easy export to Excel

---

## 📁 Project Structure

```
mumbai-consulting-firm/
├── components/
│   ├── Hero.tsx                 # Landing section with CTAs
│   ├── Services.tsx             # Service cards with animations
│   ├── Assessment.tsx           # 11-point diagnostic tool
│   ├── LeadCaptureModal.tsx     # Lead form with validation
│   ├── Header.tsx               # Navigation bar
│   ├── Footer.tsx               # Footer section
│   ├── Expertise.tsx            # Why choose us
│   └── Contact.tsx              # Contact information
├── api/
│   ├── lead-capture.ts          # Lead submission endpoint
│   └── audit-submission.ts      # Audit submission endpoint
├── styles/
│   └── globals.css              # Global styles & animations
├── App.tsx                      # Main app component
├── package.json                 # Dependencies
├── vercel.json                  # Vercel configuration
└── DEPLOYMENT_GUIDE.md          # Step-by-step setup guide
```

---

## 🔧 Local Development

### Prerequisites
- Node.js 18+ installed
- npm or yarn

### Setup
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Open browser
http://localhost:3000
```

---

## 📧 Email Template Features

### Lead Capture Email
```
Subject: 🎯 NEW LEAD: [Name] - [Business]

Includes:
- Customer name
- Email (clickable mailto:)
- Phone (clickable tel:)
- Business name
- Source (Website)
- Timestamp (IST)
- Quick action buttons
```

### Audit Completion Email
```
Subject: 📊 AUDIT COMPLETED: [Name] - [Business] (Score: X/100)

Includes:
- Customer information table
- Large health score display
- Business metrics table
- Red flags table (color-coded by severity)
- Next steps checklist
```

---

## 📊 Google Sheets Structure

### Sheet 1: "Leads"
| Timestamp | Name | Email | Phone | Business Name | Source | Status |
|-----------|------|-------|-------|---------------|--------|--------|

### Sheet 2: "Audits"
| Timestamp | Name | Email | Phone | Business | Industry | ... 15+ more columns... |
|-----------|------|-------|-------|----------|----------|------------------------|

All data is automatically appended in real-time.

---

## 🎨 Design Features

### Animations
- **fadeInLeft**: Hero content entrance
- **fadeInRight**: Hero logo entrance
- **fadeInUp**: Service cards, modal
- **float**: Particle effects
- **gradient**: Text gradients
- **bounce-slow**: CTA button
- **pulse-slow**: Glowing effects

### Color Scheme
- **Primary**: #FF1493 (Deep Pink)
- **Secondary**: #000000 (Black)
- **Background**: #FFFFFF (White)
- **Accents**: Pink gradients, shadows

### Typography
- **Headings**: Space Grotesk (bold, modern)
- **Body**: Inter (clean, readable)
- **Logo**: System UI (professional)

---

## 🔒 Security

### Frontend Validation
✅ Real email format check
✅ Phone number format (digits only, 7-15 chars)
✅ Required field validation
✅ Country code dropdown
✅ Minimum character limits

### Backend Security
✅ Environment variables for secrets
✅ Gmail App Password (not main password)
✅ Google Service Account (limited permissions)
✅ CORS headers configured
✅ Input sanitization

### What's Protected
- Gmail password
- Google Service Account key
- Spreadsheet ID
- API endpoints

---

## 📱 Responsive Design

### Breakpoints
- **Mobile**: < 768px (single column, larger buttons)
- **Tablet**: 768px - 1024px (2-column grid)
- **Desktop**: > 1024px (3-column grid, full features)

### Mobile Optimizations
- Hamburger menu
- Stacked form fields
- Larger touch targets
- Optimized font sizes
- Simplified animations

---

## 🎯 Conversion Optimizations

### Hero Section
- Clear value proposition
- Prominent "Get FREE Audit" CTA (extra large)
- "BOOK NOW" button (even larger)
- Trust indicators (checkmarks)
- "Why take the audit?" explanation
- Gradient button with hover effects

### Lead Capture
- Modal appears on CTA click
- Clear benefit statement
- Progress indication
- Confidentiality notice
- No credit card required

### Assessment
- Only shows after lead capture
- Auto-scrolls to form
- Industry-specific benchmarks
- Real-time metric calculations
- Visual progress feedback

---

## 📈 Analytics Integration (Optional)

Add these for tracking:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>

<!-- Facebook Pixel -->
<script>!function(f,b,e,v,n,t,s)...</script>

<!-- LinkedIn Insight Tag -->
<script type="text/javascript">...</script>
```

---

## 🐛 Troubleshooting

### Common Issues

**1. "Cannot POST /api/lead-capture"**
- Check Vercel deployment logs
- Verify environment variables are set
- Ensure API route file exists

**2. "Email not received"**
- Check Gmail spam folder
- Verify Gmail App Password
- Check Vercel logs for errors

**3. "Google Sheets error"**
- Verify sheet is shared with service account
- Check spreadsheet ID
- Ensure correct sheet names ("Leads", "Audits")

**4. "Form won't submit"**
- Check browser console for errors
- Verify all required fields are filled
- Check phone/email validation

---

## 🚀 Deployment Checklist

- [ ] Code pushed to GitHub
- [ ] Vercel project created
- [ ] Gmail App Password generated
- [ ] Google Spreadsheet created with headers
- [ ] Service Account created
- [ ] Spreadsheet shared with service account
- [ ] All 4 environment variables added to Vercel
- [ ] Dependencies installed
- [ ] First deployment successful
- [ ] Lead capture tested
- [ ] Audit submission tested
- [ ] Emails received
- [ ] Google Sheets updating

---

## 📞 Support

**Developer Email**: aryanimbalkar03@gmail.com
**Phone**: +91 9833411578

---

## 📄 License

Proprietary - Mumbai Consulting Firm

---

## 🎉 Success!

Your professional consulting website is now live with:
- Lead generation system
- AI-powered diagnostics
- Email automation
- Database integration
- Beautiful UI/UX

**Next Steps:**
1. Test all features thoroughly
2. Share your website URL
3. Monitor Google Sheets for leads
4. Respond to inquiries promptly
5. Iterate based on user feedback

---

Made with ❤️ for Mumbai Consulting Firm
